# CalcVerse Pro — Google AdSense Integration, Configuration & Monetization Guide

## 1. Google AdSense Integration Architecture
CalcVerse Pro includes a compliant, zero-layout-shift (CLS-safe) Google AdSense integration built directly into `calcverse_hub.html` (and modular `index.html` + `js/app.js`):
- **Head Script Loader**: Placed inside `<head>` using the configurable placeholder `ca-pub-XXXXXXXXXXXXXXXX` and guarded by `ensureAdSenseScriptLoaded()` so the script is never loaded twice.
- **No Fake Ads in Production**: When `ca-pub-XXXXXXXXXXXXXXXX` is unconfigured, ad containers remain cleanly hidden in production mode (`inspectorMode: false`). You can preview the exact reserved container dimensions anytime by clicking **⚙️ AdSense Config & Inspector** in the footer and toggling **Show Reserved Ad Slot Containers (Layout Inspector)**.

## 2. Strategic Ad Placements (7 Isolated, Policy-Compliant Locations)
All 7 ad units are isolated from calculator inputs, keypad buttons, and output readouts to prevent accidental clicks:
1. `header_banner` (`SLOT_HEADER_BANNER`) — Top Leaderboard (`min-height: 90px`) above the Complete Calculator Directory.
2. `homepage_content` (`SLOT_HOMEPAGE_CONTENT`) — Responsive horizontal unit (`min-height: 100px`) between the Calculator Directory and the Scientific Calculator section.
3. `between_sections` (`SLOT_BETWEEN_SECTIONS`) — Responsive banner (`min-height: 100px`) between the Scientific Calculator section and the Active Calculator Workspace.
4. `calculator_result` (`SLOT_CALCULATOR_RESULT`) — Placed safely below the Formula & Step-by-Step Solution box (`min-height: 120px`), well separated from input controls and primary KPI results.
5. `desktop_sidebar` (`SLOT_DESKTOP_SIDEBAR`) — Vertical desktop sidebar unit (`min-height: 250px`, visible on `lg` screens alongside the directory).
6. `footer_banner` (`SLOT_FOOTER_BANNER`) — Bottom leaderboard (`min-height: 90px`) above the compliance footer.
7. `mobile_banner` (`SLOT_MOBILE_BANNER`) — Mobile-only responsive unit (`min-height: 80px`, `md:hidden`).

## 3. Publisher ID Configuration Instructions
1. Open `calcverse_hub.html` (or `index.html` and `js/app.js`).
2. In `<head>`, locate the comment `<!-- GOOGLE ADSENSE OFFICIAL SCRIPT (CONFIGURE PUBLISHER ID BELOW) -->` and replace `ca-pub-XXXXXXXXXXXXXXXX` with your real Google AdSense Publisher ID (e.g., `ca-pub-1234567890123456`).
3. In `DEFAULT_ADSENSE_CONFIG` inside the script (or via the in-app **⚙️ AdSense Config & Inspector** modal), update `publisherId: 'ca-pub-XXXXXXXXXXXXXXXX'` to your real Publisher ID.
4. Update `ads.txt` in your root domain directory by replacing `pub-XXXXXXXXXXXXXXXX` with your Publisher ID.

## 4. Ad Slot ID Configuration Instructions
1. In your Google AdSense dashboard, navigate to **Ads → By ad unit → Display ads** and create your responsive ad units.
2. Copy the 10-digit `data-ad-slot` number for each unit.
3. Replace the placeholders in `DEFAULT_ADSENSE_CONFIG.placements` (`SLOT_HEADER_BANNER`, `SLOT_HOMEPAGE_CONTENT`, `SLOT_BETWEEN_SECTIONS`, `SLOT_CALCULATOR_RESULT`, `SLOT_DESKTOP_SIDEBAR`, `SLOT_FOOTER_BANNER`, `SLOT_MOBILE_BANNER`) or paste them directly inside the **⚙️ AdSense Config & Inspector** modal.

## 5. Google AdSense Approval Preparation Checklist
- [x] **24+ High-Value Original Calculators** with step-by-step mathematical formulas and visual charts.
- [x] **Mandatory Legal & Compliance Pages** included and accessible in the footer: **About Us**, **Contact Us** (with working form), **Privacy Policy** (with DoubleClick DART cookie disclosure and Google Ads Settings opt-out link), **Terms & Conditions**, and **Disclaimer**.
- [x] **GDPR / CCPA Cookie Consent Banner** (`#cookieConsentBanner`) with Personalized vs. Non-Personalized choice.
- [x] **Technical SEO Files**: Canonical link tag, OpenGraph metadata, JSON-LD `WebApplication` schema, `sitemap.xml`, `robots.txt` (allowing `Mediapartners-Google`), and `ads.txt`.
- [x] **Pre-Approval Clean State**: Keep `ca-pub-XXXXXXXXXXXXXXXX` or enable only the `<head>` verification snippet during initial review; never display fake banner images.

## 6. Deployment Instructions
1. Upload the contents of `calcverse_production_suite.zip` (`index.html`, `css/styles.css`, `js/app.js`, `sitemap.xml`, `robots.txt`, `ads.txt`) to your web host (Cloudflare Pages, Vercel, Netlify, GitHub Pages, or Nginx/Apache).
2. Update `https://calcverse.example.com/` in `<link rel="canonical">`, `sitemap.xml`, and `robots.txt` to your live production domain.
3. Verify `https://yourdomain.com/ads.txt` is publicly reachable.

## 7. Verification & QA Testing Report
| Test Case | Status | Verification Details |
| :--- | :--- | :--- |
| **AdSense Script Loading & Deduplication** | PASS | Single `<script async>` tag in `<head>`; `window.__calcverseAdSenseInitialized` prevents duplicate loading. |
| **Desktop & Mobile Ad Layouts (CLS = 0)** | PASS | Explicit `min-height` reservation (`80px`–`250px`) prevents layout shift; `desktop` and `mobile` flags control viewport visibility. |
| **Ad Blocker & Unfilled Ad Resilience** | PASS | `pushAdUnitSafely()` wraps `(adsbygoogle = window.adsbygoogle || []).push({})` in `try/catch` with zero console errors. |
| **Calculator & Feature Preservation** | PASS | All 24 calculators, Scientific Keypad, Omnibox Search, Nostalgic Paper Slip, Account Login/Sign-Up, and PDF/Excel/PNG exports verified via `check_web_app.py` with 0 errors and 0 warnings. |
