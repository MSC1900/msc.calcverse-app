// =========================================================================
    // 1. SAFE STORAGE & TOAST HELPERS
    // =========================================================================
    function safeGetStorage(key, fallback) {
      try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
      } catch (e) {
        return fallback;
      }
    }

    function safeSetStorage(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (e) {
        // Ignore storage errors in sandboxed frames
      }
    }

    let toastTimer = null;
    function showToast(msg) {
      const banner = document.getElementById('toastBanner');
      const text = document.getElementById('toastMessage');
      if (!banner || !text) return;
      text.textContent = msg;
      banner.classList.remove('hidden');
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        banner.classList.add('hidden');
      }, 2400);
    }

    function copyTextToClipboard(str, label) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(str).then(() => {
          showToast(label || 'Copied to clipboard!');
        }).catch(() => fallbackCopy(str, label));
      } else {
        fallbackCopy(str, label);
      }
    }

    function fallbackCopy(str, label) {
      const ta = document.createElement('textarea');
      ta.value = str;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        showToast(label || 'Copied to clipboard!');
      } catch (e) {
        showToast('Ready to copy');
      }
      document.body.removeChild(ta);
    }

    function fmtCurrency(val) {
      if (!isFinite(val)) return '$0.00';
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(val);
    }

    function fmtNum(val, dec = 2) {
      if (!isFinite(val)) return '0';
      return Number(val).toLocaleString('en-US', { maximumFractionDigits: dec });
    }

    // =========================================================================
    // 2. SCIENTIFIC & BASIC CALCULATOR ENGINE
    // =========================================================================
    const sciState = {
      degMode: true,
      sciMode: true,
      memory: 0,
      ans: 0,
      tape: []
    };

    const sciScreenInput = document.getElementById('sciScreenInput');
    const sciExpressionDisplay = document.getElementById('sciExpressionDisplay');
    const sciMemoryIndicator = document.getElementById('sciMemoryIndicator');
    const sciTapeList = document.getElementById('sciTapeList');

    function updateSciIndicators() {
      sciMemoryIndicator.textContent = `M = ${fmtNum(sciState.memory, 4)}`;
    }

    function appendToSciScreen(token) {
      const cur = sciScreenInput.value.trim();
      if (cur === '0' || cur === 'Error' || cur === 'Infinity' || cur === 'NaN') {
        sciScreenInput.value = String(token);
      } else {
        sciScreenInput.value = cur + String(token);
      }
    }

    function factorial(n) {
      const k = Math.floor(Number(n));
      if (k < 0 || !isFinite(k)) return NaN;
      if (k === 0 || k === 1) return 1;
      if (k > 170) return Infinity;
      let res = 1;
      for (let i = 2; i <= k; i++) res *= i;
      return res;
    }

    function evaluateSciExpression(exprStr) {
      const cleaned = exprStr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/π/g, String(Math.PI));
      // Safe math evaluation using Function with restricted numeric tokens
      const safeCheck = /^[0-9+\-*/().\sEepi]+$/;
      if (!safeCheck.test(cleaned)) {
        return NaN;
      }
      try {
        const fn = new Function(`"use strict"; return (${cleaned});`);
        return Number(fn());
      } catch (e) {
        return NaN;
      }
    }

    function renderSciTape() {
      if (sciState.tape.length === 0) {
        sciTapeList.innerHTML = '<div class="text-slate-400 dark:text-slate-500 py-3 text-center">Try calculating an expression on the keypad or click any entry to reuse its value.</div>';
        return;
      }
      sciTapeList.innerHTML = sciState.tape.slice().reverse().map((item, idx) => `
        <button type="button" data-tape-val="${item.result}" class="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between gap-2 transition">
          <span class="text-slate-500 dark:text-slate-400 truncate">${item.expr} =</span>
          <span class="font-bold text-indigo-600 dark:text-indigo-400">${fmtNum(item.result, 6)}</span>
        </button>
      `).join('');
    }

    function pushSciTape(expr, result) {
      if (!isFinite(result)) return;
      sciState.tape.push({ expr, result });
      if (sciState.tape.length > 20) sciState.tape.shift();
      renderSciTape();
    }

    function applyUnarySci(label, fn) {
      const currentVal = evaluateSciExpression(sciScreenInput.value);
      if (isNaN(currentVal)) {
        sciScreenInput.value = 'Error';
        return;
      }
      const out = fn(currentVal);
      sciExpressionDisplay.textContent = `${label}(${fmtNum(currentVal, 4)})`;
      sciScreenInput.value = isFinite(out) ? String(Number(out.toPrecision(12))) : 'Error';
      if (isFinite(out)) {
        sciState.ans = out;
        pushSciTape(`${label}(${fmtNum(currentVal, 4)})`, out);
      }
    }

    document.querySelectorAll('[data-sci-num]').forEach(btn => {
      btn.addEventListener('click', () => appendToSciScreen(btn.getAttribute('data-sci-num')));
    });

    document.querySelectorAll('[data-sci-op]').forEach(btn => {
      btn.addEventListener('click', () => {
        const op = btn.getAttribute('data-sci-op');
        appendToSciScreen(op);
      });
    });

    document.querySelectorAll('[data-sci-act]').forEach(btn => {
      btn.addEventListener('click', () => {
        const act = btn.getAttribute('data-sci-act');
        const toRad = x => sciState.degMode ? (x * Math.PI / 180) : x;
        const fromRad = x => sciState.degMode ? (x * 180 / Math.PI) : x;

        switch (act) {
          case 'ac':
            sciScreenInput.value = '0';
            sciExpressionDisplay.textContent = `Ans = ${fmtNum(sciState.ans, 4)}`;
            break;
          case 'back': {
            const s = sciScreenInput.value;
            sciScreenInput.value = s.length > 1 ? s.slice(0, -1) : '0';
            break;
          }
          case 'eval': {
            const raw = sciScreenInput.value;
            const res = evaluateSciExpression(raw);
            sciExpressionDisplay.textContent = `${raw} =`;
            if (isFinite(res)) {
              sciState.ans = res;
              sciScreenInput.value = String(Number(res.toPrecision(12)));
              pushSciTape(raw, res);
            } else {
              sciScreenInput.value = 'Error';
            }
            break;
          }
          case 'sin': applyUnarySci('sin', x => Math.sin(toRad(x))); break;
          case 'cos': applyUnarySci('cos', x => Math.cos(toRad(x))); break;
          case 'tan': applyUnarySci('tan', x => Math.tan(toRad(x))); break;
          case 'asin': applyUnarySci('sin⁻¹', x => fromRad(Math.asin(x))); break;
          case 'acos': applyUnarySci('cos⁻¹', x => fromRad(Math.acos(x))); break;
          case 'atan': applyUnarySci('tan⁻¹', x => fromRad(Math.atan(x))); break;
          case 'sq': applyUnarySci('sqr', x => x * x); break;
          case 'cube': applyUnarySci('cube', x => x * x * x); break;
          case 'sqrt': applyUnarySci('√', x => Math.sqrt(x)); break;
          case 'cbrt': applyUnarySci('³√', x => Math.cbrt(x)); break;
          case 'ln': applyUnarySci('ln', x => Math.log(x)); break;
          case 'log': applyUnarySci('log₁₀', x => Math.log10(x)); break;
          case 'inv': applyUnarySci('1/', x => 1 / x); break;
          case 'fact': applyUnarySci('fact', x => factorial(x)); break;
          case 'exp10': applyUnarySci('10^', x => Math.pow(10, x)); break;
          case 'sinh': applyUnarySci('sinh', x => Math.sinh(x)); break;
          case 'cosh': applyUnarySci('cosh', x => Math.cosh(x)); break;
          case 'tanh': applyUnarySci('tanh', x => Math.tanh(x)); break;
          case 'log2': applyUnarySci('log₂', x => Math.log2(x)); break;
          case 'abs': applyUnarySci('abs', x => Math.abs(x)); break;
          case 'exp2': applyUnarySci('2^', x => Math.pow(2, x)); break;
          case 'expe': applyUnarySci('e^', x => Math.exp(x)); break;
          case 'floor': applyUnarySci('floor', x => Math.floor(x)); break;
          case 'ceil': applyUnarySci('ceil', x => Math.ceil(x)); break;
          case 'mc':
            sciState.memory = 0;
            updateSciIndicators();
            showToast('Memory Cleared (MC)');
            break;
          case 'pow': appendToSciScreen('**'); break;
          case 'lparen': appendToSciScreen('('); break;
          case 'rparen': appendToSciScreen(')'); break;
          case 'pi': sciScreenInput.value = String(Number(Math.PI.toFixed(10))); break;
          case 'e': sciScreenInput.value = String(Number(Math.E.toFixed(10))); break;
          case 'pct': applyUnarySci('%', x => x / 100); break;
          case 'neg': applyUnarySci('±', x => -x); break;
          case 'rnd': sciScreenInput.value = String(Number(Math.random().toFixed(6))); break;
          case 'ans': appendToSciScreen(String(Number(sciState.ans.toFixed(6)))); break;
          case 'mplus': {
            const v = evaluateSciExpression(sciScreenInput.value);
            if (isFinite(v)) { sciState.memory += v; updateSciIndicators(); showToast('Added to Memory (M+)'); }
            break;
          }
          case 'mminus': {
            const v = evaluateSciExpression(sciScreenInput.value);
            if (isFinite(v)) { sciState.memory -= v; updateSciIndicators(); showToast('Subtracted from Memory (M−)'); }
            break;
          }
          case 'mr':
            sciScreenInput.value = String(sciState.memory);
            break;
        }
      });
    });

    sciTapeList.addEventListener('click', e => {
      const btn = e.target.closest('[data-tape-val]');
      if (btn) {
        sciScreenInput.value = btn.getAttribute('data-tape-val');
      }
    });

    document.getElementById('clearSciTapeBtn').addEventListener('click', () => {
      sciState.tape = [];
      renderSciTape();
    });

    document.getElementById('copySciResultBtn').addEventListener('click', () => {
      copyTextToClipboard(sciScreenInput.value, `Copied ${sciScreenInput.value} to clipboard!`);
    });

    document.getElementById('sciModeBtn').addEventListener('click', () => {
      document.getElementById('sciFunctionPad').classList.remove('hidden');
      document.getElementById('sciModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold bg-indigo-600 text-white';
      document.getElementById('basicModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold text-slate-300 hover:text-white';
    });

    document.getElementById('basicModeBtn').addEventListener('click', () => {
      document.getElementById('sciFunctionPad').classList.add('hidden');
      document.getElementById('basicModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold bg-indigo-600 text-white';
      document.getElementById('sciModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold text-slate-300 hover:text-white';
    });

    document.getElementById('degModeBtn').addEventListener('click', () => {
      sciState.degMode = true;
      document.getElementById('degModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold bg-cyan-600 text-white';
      document.getElementById('radModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold text-slate-300 hover:text-white';
    });

    document.getElementById('radModeBtn').addEventListener('click', () => {
      sciState.degMode = false;
      document.getElementById('radModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold bg-cyan-600 text-white';
      document.getElementById('degModeBtn').className = 'px-2.5 py-1 rounded-md font-semibold text-slate-300 hover:text-white';
    });

    // =========================================================================
    // 3. 24 SPECIALIZED CALCULATORS CATALOG & ENGINE
    // =========================================================================
    const CALCULATORS = [
      // ---------------- FINANCIAL (7) ----------------
      {
        id: 'mortgage',
        name: 'Mortgage Calculator',
        category: 'Financial',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
        popular: true,
        desc: 'Monthly payment breakdown, property tax, home insurance & amortization table',
        inputs: [
          { key: 'homePrice', label: 'Home Price ($)', type: 'number', default: 420000, min: 10000, step: 5000 },
          { key: 'downPaymentPct', label: 'Down Payment (%)', type: 'number', default: 20, min: 0, max: 95, step: 1 },
          { key: 'termYears', label: 'Loan Term (Years)', type: 'select', default: 30, options: [{v: 30, l: '30 Years Fixed'}, {v: 20, l: '20 Years Fixed'}, {v: 15, l: '15 Years Fixed'}, {v: 10, l: '10 Years Fixed'}] },
          { key: 'rate', label: 'Annual Interest Rate (%)', type: 'number', default: 6.25, min: 0.1, max: 25, step: 0.05 },
          { key: 'propTaxYr', label: 'Annual Property Tax ($)', type: 'number', default: 4800, min: 0, step: 100 },
          { key: 'insYr', label: 'Annual Home Insurance ($)', type: 'number', default: 1500, min: 0, step: 100 }
        ],
        compute(v) {
          const downAmt = v.homePrice * (v.downPaymentPct / 100);
          const principal = Math.max(0, v.homePrice - downAmt);
          const n = Math.max(1, v.termYears * 12);
          const r = (v.rate / 100) / 12;
          const pi = r === 0 ? principal / n : principal * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
          const taxMo = v.propTaxYr / 12;
          const insMo = v.insYr / 12;
          const totalMo = pi + taxMo + insMo;
          const totalInterest = (pi * n) - principal;

          const pPct = totalMo > 0 ? Math.round((pi / totalMo) * 100) : 0;
          const tPct = totalMo > 0 ? Math.round((taxMo / totalMo) * 100) : 0;
          const iPct = Math.max(0, 100 - pPct - tPct);

          return {
            summaryLabel: `${fmtCurrency(totalMo)}/mo`,
            kpis: [
              { label: 'Total Monthly Payment', value: fmtCurrency(totalMo), sub: `P&I: ${fmtCurrency(pi)}` },
              { label: 'Loan Principal', value: fmtCurrency(principal), sub: `Down: ${fmtCurrency(downAmt)}` },
              { label: 'Total Interest Paid', value: fmtCurrency(totalInterest), sub: `Total Loan Cost: ${fmtCurrency(principal + totalInterest)}` }
            ],
            visualHtml: `
              <div class="space-y-3">
                <div class="w-full h-5 rounded-full overflow-hidden flex bg-slate-200 dark:bg-slate-800">
                  <div style="width:${pPct}%" class="bg-indigo-600 h-full" title="Principal & Interest"></div>
                  <div style="width:${tPct}%" class="bg-cyan-500 h-full" title="Property Tax"></div>
                  <div style="width:${iPct}%" class="bg-amber-500 h-full" title="Home Insurance"></div>
                </div>
                <div class="grid grid-cols-3 gap-2 text-xs">
                  <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-indigo-600"></span><span>P&amp;I: <strong>${fmtCurrency(pi)}</strong> (${pPct}%)</span></div>
                  <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-cyan-500"></span><span>Tax: <strong>${fmtCurrency(taxMo)}</strong> (${tPct}%)</span></div>
                  <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span><span>Insurance: <strong>${fmtCurrency(insMo)}</strong> (${iPct}%)</span></div>
                </div>
              </div>
            `,
            formulaSteps: [
              `Formula: M = P × [ r(1 + r)ⁿ ] / [ (1 + r)ⁿ − 1 ]`,
              `P (Loan Principal) = ${fmtCurrency(v.homePrice)} − ${fmtCurrency(downAmt)} = ${fmtCurrency(principal)}`,
              `r (Monthly Rate) = ${v.rate}% ÷ 12 = ${(r * 100).toFixed(4)}%, n = ${n} monthly payments`,
              `Monthly P&I = ${fmtCurrency(pi)} + Tax (${fmtCurrency(taxMo)}) + Insurance (${fmtCurrency(insMo)}) = ${fmtCurrency(totalMo)}/mo`
            ]
          };
        }
      },
      {
        id: 'loan',
        name: 'Loan & Auto Payment Calculator',
        category: 'Financial',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>',
        popular: true,
        desc: 'Amortized monthly payment, total interest & payoff breakdown for personal or auto loans',
        inputs: [
          { key: 'amount', label: 'Loan Amount ($)', type: 'number', default: 32000, min: 500, step: 500 },
          { key: 'months', label: 'Loan Term (Months)', type: 'number', default: 60, min: 6, max: 360, step: 6 },
          { key: 'apr', label: 'Interest Rate / APR (%)', type: 'number', default: 5.9, min: 0, max: 35, step: 0.1 },
          { key: 'extraMo', label: 'Extra Monthly Payment ($)', type: 'number', default: 50, min: 0, step: 25 }
        ],
        compute(v) {
          const P = Math.max(0, v.amount);
          const n = Math.max(1, v.months);
          const r = (v.apr / 100) / 12;
          const baseMo = r === 0 ? P / n : P * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
          const baseTotalInt = (baseMo * n) - P;

          // Simulate with extra payment
          let bal = P;
          let actualMonths = 0;
          let actualInt = 0;
          const pay = baseMo + Math.max(0, v.extraMo);
          while (bal > 0.01 && actualMonths < 600) {
            const intPart = bal * r;
            actualInt += intPart;
            bal = bal + intPart - pay;
            actualMonths++;
          }
          const savedInt = Math.max(0, baseTotalInt - actualInt);
          const savedMo = Math.max(0, n - actualMonths);

          return {
            summaryLabel: `${fmtCurrency(baseMo)}/mo`,
            kpis: [
              { label: 'Required Monthly Payment', value: fmtCurrency(baseMo), sub: `With Extra: ${fmtCurrency(pay)}/mo` },
              { label: 'Total Interest (Base)', value: fmtCurrency(baseTotalInt), sub: `Interest Saved: ${fmtCurrency(savedInt)}` },
              { label: 'Payoff Time with Extra', value: `${actualMonths} mos`, sub: `Saves ${savedMo} months early` }
            ],
            visualHtml: `
              <div class="grid grid-cols-2 gap-3 text-xs">
                <div class="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <div class="text-slate-500">Standard Schedule (${n} mos)</div>
                  <div class="text-sm font-bold mt-1">Total Paid: ${fmtCurrency(P + baseTotalInt)}</div>
                </div>
                <div class="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                  <div class="text-emerald-700 dark:text-emerald-300">Accelerated (${actualMonths} mos)</div>
                  <div class="text-sm font-bold text-emerald-700 dark:text-emerald-300 mt-1">Total Paid: ${fmtCurrency(P + actualInt)}</div>
                </div>
              </div>
            `,
            formulaSteps: [
              `Amortization Formula: Payment = P × [r(1+r)ⁿ] / [(1+r)ⁿ − 1]`,
              `Base Monthly Payment = ${fmtCurrency(baseMo)} over ${n} months`,
              `Adding ${fmtCurrency(v.extraMo)}/mo saves ${fmtCurrency(savedInt)} in interest and shortens payoff by ${savedMo} months.`
            ]
          };
        }
      },
      {
        id: 'compound',
        name: 'Compound Interest & Investment Calculator',
        category: 'Financial',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
        popular: true,
        desc: 'Project wealth growth with initial deposit, monthly contributions & compounding frequency',
        inputs: [
          { key: 'initial', label: 'Initial Investment ($)', type: 'number', default: 15000, min: 0, step: 1000 },
          { key: 'monthly', label: 'Monthly Contribution ($)', type: 'number', default: 500, min: 0, step: 50 },
          { key: 'years', label: 'Investment Horizon (Years)', type: 'number', default: 20, min: 1, max: 60, step: 1 },
          { key: 'rate', label: 'Annual Return Rate (%)', type: 'number', default: 8.0, min: 0, max: 30, step: 0.25 },
          { key: 'compFreq', label: 'Compounding Frequency', type: 'select', default: 12, options: [{v: 12, l: 'Monthly (12/yr)'}, {v: 4, l: 'Quarterly (4/yr)'}, {v: 1, l: 'Annually (1/yr)'}, {v: 365, l: 'Daily (365/yr)'}] }
        ],
        compute(v) {
          const yrs = Math.max(1, Math.min(60, v.years));
          const r = v.rate / 100;
          let balance = v.initial;
          let totalContributed = v.initial;
          const yearlyBars = [];

          for (let y = 1; y <= yrs; y++) {
            for (let m = 1; m <= 12; m++) {
              balance = balance * (1 + r / 12) + v.monthly;
              totalContributed += v.monthly;
            }
            yearlyBars.push({ year: y, balance, contributed: totalContributed });
          }
          const totalInterest = balance - totalContributed;
          const maxBal = Math.max(balance, 1);
          const step = Math.max(1, Math.floor(yearlyBars.length / 10));
          const sampled = yearlyBars.filter((_, idx) => (idx + 1) % step === 0 || idx === yearlyBars.length - 1);

          return {
            summaryLabel: fmtCurrency(balance),
            kpis: [
              { label: 'Ending Balance', value: fmtCurrency(balance), sub: `After ${yrs} years at ${v.rate}%` },
              { label: 'Total Principal Contributed', value: fmtCurrency(totalContributed), sub: `Initial + ${fmtCurrency(v.monthly)}/mo` },
              { label: 'Total Compound Return', value: fmtCurrency(totalInterest), sub: `${Math.round((totalInterest / Math.max(1, balance)) * 100)}% of final wealth` }
            ],
            visualHtml: `
              <div class="space-y-2">
                <div class="flex items-end gap-1.5 h-32 pt-4 px-2">
                  ${sampled.map(item => {
                    const totalH = Math.max(8, Math.round((item.balance / maxBal) * 100));
                    const prinH = Math.max(4, Math.round((item.contributed / maxBal) * 100));
                    return `
                      <div class="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                        <div class="w-full rounded-t bg-indigo-500 relative overflow-hidden" style="height:${totalH}%" title="Year ${item.year}: ${fmtCurrency(item.balance)}">
                          <div class="w-full bg-cyan-400 bottom-0 absolute" style="height:${Math.min(100, Math.round((prinH/totalH)*100))}%"></div>
                        </div>
                        <span class="text-[10px] text-slate-500">Y${item.year}</span>
                      </div>
                    `;
                  }).join('')}
                </div>
                <div class="flex items-center justify-center gap-4 text-xs text-slate-500">
                  <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-sm bg-cyan-400 inline-block"></span> Principal Contributed</span>
                  <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-sm bg-indigo-500 inline-block"></span> Compound Growth</span>
                </div>
              </div>
            `,
            formulaSteps: [
              `Formula: A = P(1 + r/n)^(nt) + PMT × [((1 + r/12)^(12t) − 1) / (r/12)]`,
              `Total Contributed = ${fmtCurrency(v.initial)} + (${fmtCurrency(v.monthly)} × ${yrs * 12} mos) = ${fmtCurrency(totalContributed)}`,
              `Compound Earnings = ${fmtCurrency(balance)} − ${fmtCurrency(totalContributed)} = ${fmtCurrency(totalInterest)}`
            ]
          };
        }
      },
      {
        id: 'retirement',
        name: 'Retirement & 4% Rule Calculator',
        category: 'Financial',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
        popular: false,
        desc: 'Project nest egg at retirement age and safe monthly withdrawal income',
        inputs: [
          { key: 'curAge', label: 'Current Age', type: 'number', default: 32, min: 18, max: 80, step: 1 },
          { key: 'retAge', label: 'Retirement Age', type: 'number', default: 65, min: 30, max: 90, step: 1 },
          { key: 'saved', label: 'Current Retirement Savings ($)', type: 'number', default: 45000, min: 0, step: 1000 },
          { key: 'moSave', label: 'Monthly Savings ($)', type: 'number', default: 800, min: 0, step: 50 },
          { key: 'retRate', label: 'Annual Return (%)', type: 'number', default: 7.5, min: 1, max: 20, step: 0.25 }
        ],
        compute(v) {
          const years = Math.max(1, v.retAge - v.curAge);
          const r = (v.retRate / 100) / 12;
          const n = years * 12;
          const fvSaved = v.saved * Math.pow(1 + r, n);
          const fvContrib = r === 0 ? v.moSave * n : v.moSave * ((Math.pow(1 + r, n) - 1) / r);
          const nestEgg = fvSaved + fvContrib;
          const safeMonthly = (nestEgg * 0.04) / 12;

          return {
            summaryLabel: fmtCurrency(nestEgg),
            kpis: [
              { label: 'Projected Nest Egg', value: fmtCurrency(nestEgg), sub: `In ${years} years (Age ${v.retAge})` },
              { label: 'Safe Monthly Income (4% Rule)', value: fmtCurrency(safeMonthly), sub: `${fmtCurrency(safeMonthly * 12)}/year` },
              { label: 'Growth from Current Savings', value: fmtCurrency(fvSaved), sub: `Contributions grow to ${fmtCurrency(fvContrib)}` }
            ],
            visualHtml: `
              <div class="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                <div class="flex justify-between"><span>Existing Savings Growth:</span><strong>${fmtCurrency(fvSaved)}</strong></div>
                <div class="flex justify-between"><span>Future Monthly Contributions Growth:</span><strong>${fmtCurrency(fvContrib)}</strong></div>
                <div class="flex justify-between text-indigo-600 dark:text-indigo-400"><span>Sustainable 4% Annual Withdrawal:</span><strong>${fmtCurrency(nestEgg * 0.04)}/yr</strong></div>
              </div>
            `,
            formulaSteps: [
              `Years to Retirement = ${v.retAge} − ${v.curAge} = ${years} years (${n} months)`,
              `Nest Egg = Current × (1+r)ⁿ + PMT × [((1+r)ⁿ − 1)/r] = ${fmtCurrency(nestEgg)}`,
              `Safe Monthly Withdrawal (4% Rule) = (${fmtCurrency(nestEgg)} × 0.04) ÷ 12 = ${fmtCurrency(safeMonthly)}/mo`
            ]
          };
        }
      },
      {
        id: 'inflation',
        name: 'Inflation & Purchasing Power Calculator',
        category: 'Financial',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
        popular: false,
        desc: 'Calculate future cost of goods and purchasing power erosion over time',
        inputs: [
          { key: 'amount', label: 'Current Amount ($)', type: 'number', default: 1000, min: 1, step: 100 },
          { key: 'infRate', label: 'Annual Inflation Rate (%)', type: 'number', default: 3.2, min: 0, max: 30, step: 0.1 },
          { key: 'years', label: 'Number of Years', type: 'number', default: 15, min: 1, max: 100, step: 1 }
        ],
        compute(v) {
          const futureCost = v.amount * Math.pow(1 + v.infRate / 100, v.years);
          const realValue = v.amount / Math.pow(1 + v.infRate / 100, v.years);
          const lossPct = ((v.amount - realValue) / v.amount) * 100;
          return {
            summaryLabel: fmtCurrency(futureCost),
            kpis: [
              { label: 'Equivalent Future Cost', value: fmtCurrency(futureCost), sub: `To buy what ${fmtCurrency(v.amount)} buys today` },
              { label: 'Future Purchasing Power', value: fmtCurrency(realValue), sub: `Value of ${fmtCurrency(v.amount)} in ${v.years} yrs` },
              { label: 'Purchasing Power Erosion', value: `${lossPct.toFixed(1)}%`, sub: `At ${v.infRate}% annual inflation` }
            ],
            visualHtml: `
              <div class="space-y-2 text-xs">
                <div class="flex justify-between"><span>Today's Purchasing Power (100%)</span><span>Future Buying Power (${(100 - lossPct).toFixed(1)}%)</span></div>
                <div class="w-full h-4 rounded-full bg-rose-100 dark:bg-rose-950 overflow-hidden">
                  <div class="h-full bg-emerald-500" style="width:${Math.max(5, 100 - lossPct)}%"></div>
                </div>
              </div>
            `,
            formulaSteps: [
              `Future Cost = Present × (1 + i)ⁿ = ${fmtCurrency(v.amount)} × (1 + ${v.infRate / 100})^${v.years} = ${fmtCurrency(futureCost)}`,
              `Real Buying Power = Present ÷ (1 + i)ⁿ = ${fmtCurrency(realValue)}`
            ]
          };
        }
      },
      {
        id: 'salary',
        name: 'Salary & Hourly Paycheck Converter',
        category: 'Financial',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>',
        popular: false,
        desc: 'Convert between hourly wage, weekly, biweekly, monthly and annual salary',
        inputs: [
          { key: 'hourly', label: 'Hourly Rate ($/hr)', type: 'number', default: 42, min: 1, step: 1 },
          { key: 'hoursWk', label: 'Hours per Week', type: 'number', default: 40, min: 1, max: 100, step: 1 },
          { key: 'weeksYr', label: 'Working Weeks per Year', type: 'number', default: 52, min: 1, max: 52, step: 1 },
          { key: 'taxPct', label: 'Estimated Effective Tax (%)', type: 'number', default: 22, min: 0, max: 60, step: 1 }
        ],
        compute(v) {
          const weekly = v.hourly * v.hoursWk;
          const annualGross = weekly * v.weeksYr;
          const annualNet = annualGross * (1 - v.taxPct / 100);
          const monthlyNet = annualNet / 12;
          return {
            summaryLabel: `${fmtCurrency(annualGross)}/yr`,
            kpis: [
              { label: 'Annual Gross Salary', value: fmtCurrency(annualGross), sub: `Net After Tax: ${fmtCurrency(annualNet)}` },
              { label: 'Monthly Take-Home', value: fmtCurrency(monthlyNet), sub: `Gross: ${fmtCurrency(annualGross / 12)}/mo` },
              { label: 'Bi-Weekly Paycheck (Net)', value: fmtCurrency(annualNet / 26), sub: `Weekly Gross: ${fmtCurrency(weekly)}` }
            ],
            visualHtml: `
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-center">
                <div class="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">Daily (8h)</div><div class="font-bold mt-0.5">${fmtCurrency(v.hourly * 8)}</div></div>
                <div class="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">Weekly</div><div class="font-bold mt-0.5">${fmtCurrency(weekly)}</div></div>
                <div class="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">Biweekly</div><div class="font-bold mt-0.5">${fmtCurrency(weekly * 2)}</div></div>
                <div class="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">Monthly</div><div class="font-bold mt-0.5">${fmtCurrency(annualGross / 12)}</div></div>
              </div>
            `,
            formulaSteps: [
              `Annual Gross = ${fmtCurrency(v.hourly)}/hr × ${v.hoursWk} hrs/wk × ${v.weeksYr} wks = ${fmtCurrency(annualGross)}`,
              `Annual Net (after ${v.taxPct}% tax) = ${fmtCurrency(annualGross)} × ${(1 - v.taxPct / 100).toFixed(2)} = ${fmtCurrency(annualNet)}`
            ]
          };
        }
      },
      {
        id: 'roi',
        name: 'ROI & Margin Calculator',
        category: 'Financial',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
        popular: false,
        desc: 'Calculate Return on Investment (ROI), annualized return, profit margin & markup',
        inputs: [
          { key: 'cost', label: 'Amount Invested / Cost ($)', type: 'number', default: 12000, min: 1, step: 100 },
          { key: 'returned', label: 'Amount Returned / Revenue ($)', type: 'number', default: 16800, min: 0, step: 100 },
          { key: 'years', label: 'Investment Period (Years)', type: 'number', default: 2.5, min: 0.1, step: 0.5 }
        ],
        compute(v) {
          const profit = v.returned - v.cost;
          const roi = (profit / Math.max(1, v.cost)) * 100;
          const margin = v.returned > 0 ? (profit / v.returned) * 100 : 0;
          const cagr = v.returned > 0 && v.cost > 0 ? (Math.pow(v.returned / v.cost, 1 / Math.max(0.1, v.years)) - 1) * 100 : 0;
          return {
            summaryLabel: `${roi.toFixed(2)}% ROI`,
            kpis: [
              { label: 'Net Profit / Gain', value: fmtCurrency(profit), sub: `Revenue: ${fmtCurrency(v.returned)}` },
              { label: 'Total ROI (%)', value: `${roi.toFixed(2)}%`, sub: `Gross Margin: ${margin.toFixed(2)}%` },
              { label: 'Annualized Return (CAGR)', value: `${cagr.toFixed(2)}%/yr`, sub: `Over ${v.years} years` }
            ],
            visualHtml: `
              <div class="flex items-center justify-between p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs">
                <span>Cost Basis: <strong>${fmtCurrency(v.cost)}</strong></span>
                <span>→</span>
                <span class="text-emerald-600 dark:text-emerald-400">Net Gain: <strong>${fmtCurrency(profit)} (${roi.toFixed(1)}%)</strong></span>
              </div>
            `,
            formulaSteps: [
              `ROI = [(Returned − Cost) ÷ Cost] × 100 = [(${fmtCurrency(v.returned)} − ${fmtCurrency(v.cost)}) ÷ ${fmtCurrency(v.cost)}] × 100 = ${roi.toFixed(2)}%`,
              `Annualized CAGR = [(Returned ÷ Cost)^(1 / Years) − 1] × 100 = ${cagr.toFixed(2)}%`
            ]
          };
        }
      },

      // ---------------- FITNESS & HEALTH (5) ----------------
      {
        id: 'bmi',
        name: 'BMI & Healthy Weight Calculator',
        category: 'Fitness & Health',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/></svg>',
        popular: true,
        desc: 'Body Mass Index, WHO category scale, Ponderal index & healthy weight range',
        inputs: [
          { key: 'heightCm', label: 'Height (cm)', type: 'number', default: 175, min: 100, max: 240, step: 1 },
          { key: 'weightKg', label: 'Weight (kg)', type: 'number', default: 72, min: 25, max: 250, step: 0.5 }
        ],
        compute(v) {
          const hM = v.heightCm / 100;
          const bmi = v.weightKg / (hM * hM);
          const minHealthy = 18.5 * hM * hM;
          const maxHealthy = 24.9 * hM * hM;
          let cat = 'Normal Weight';
          let badgeColor = 'text-emerald-600 dark:text-emerald-400';
          if (bmi < 18.5) { cat = 'Underweight'; badgeColor = 'text-cyan-600 dark:text-cyan-400'; }
          else if (bmi >= 25 && bmi < 30) { cat = 'Overweight'; badgeColor = 'text-amber-600 dark:text-amber-400'; }
          else if (bmi >= 30) { cat = 'Obesity'; badgeColor = 'text-rose-600 dark:text-rose-400'; }
          const posPct = Math.min(98, Math.max(2, ((bmi - 14) / (36 - 14)) * 100));

          return {
            summaryLabel: `BMI ${bmi.toFixed(1)} (${cat})`,
            kpis: [
              { label: 'Your BMI Score', value: bmi.toFixed(1), sub: `${cat} (WHO Standard)` },
              { label: 'Healthy Weight Range', value: `${minHealthy.toFixed(1)} – ${maxHealthy.toFixed(1)} kg`, sub: `For ${v.heightCm} cm height` },
              { label: 'Ponderal Index', value: `${(v.weightKg / Math.pow(hM, 3)).toFixed(1)} kg/m³`, sub: `Height-cubed ratio` }
            ],
            visualHtml: `
              <div class="space-y-2">
                <div class="relative w-full h-4 rounded-full overflow-hidden flex">
                  <div class="w-1/4 bg-cyan-400 h-full" title="Underweight <18.5"></div>
                  <div class="w-1/3 bg-emerald-500 h-full" title="Normal 18.5-24.9"></div>
                  <div class="w-1/5 bg-amber-400 h-full" title="Overweight 25-29.9"></div>
                  <div class="flex-1 bg-rose-500 h-full" title="Obesity 30+"></div>
                </div>
                <div class="relative h-5">
                  <div style="left:${posPct}%" class="absolute -translate-x-1/2 -top-1 text-xs font-bold ${badgeColor}">▲ ${bmi.toFixed(1)}</div>
                </div>
                <div class="flex justify-between text-[11px] text-slate-500">
                  <span>14</span><span>18.5 (Normal)</span><span>25 (Overweight)</span><span>30 (Obese)</span><span>36+</span>
                </div>
              </div>
            `,
            formulaSteps: [
              `Formula: BMI = Weight (kg) ÷ [Height (m)]²`,
              `Height in meters = ${v.heightCm} cm ÷ 100 = ${hM.toFixed(2)} m`,
              `BMI = ${v.weightKg} ÷ (${hM.toFixed(2)})² = ${bmi.toFixed(2)} kg/m² (${cat})`
            ]
          };
        }
      },
      {
        id: 'calorie',
        name: 'Calorie, TDEE & Macro Calculator',
        category: 'Fitness & Health',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
        popular: true,
        desc: 'Mifflin-St Jeor BMR, Total Daily Energy Expenditure (TDEE) & daily protein/carb/fat macros',
        inputs: [
          { key: 'sex', label: 'Biological Sex', type: 'select', default: 'male', options: [{v: 'male', l: 'Male'}, {v: 'female', l: 'Female'}] },
          { key: 'age', label: 'Age (Years)', type: 'number', default: 29, min: 15, max: 100, step: 1 },
          { key: 'heightCm', label: 'Height (cm)', type: 'number', default: 176, min: 120, max: 230, step: 1 },
          { key: 'weightKg', label: 'Weight (kg)', type: 'number', default: 74, min: 35, max: 220, step: 1 },
          { key: 'activity', label: 'Activity Multiplier', type: 'select', default: 1.55, options: [
            {v: 1.2, l: 'Sedentary (1.2×)'},
            {v: 1.375, l: 'Light Exercise 1-3d/wk (1.375×)'},
            {v: 1.55, l: 'Moderate Exercise 4-5d/wk (1.55×)'},
            {v: 1.725, l: 'Active / Intense 6-7d/wk (1.725×)'}
          ]}
        ],
        compute(v) {
          const bmr = v.sex === 'male'
            ? (10 * v.weightKg) + (6.25 * v.heightCm) - (5 * v.age) + 5
            : (10 * v.weightKg) + (6.25 * v.heightCm) - (5 * v.age) - 161;
          const tdee = bmr * Number(v.activity);
          const cutCal = tdee - 500;
          const bulkCal = tdee + 350;
          // Balanced macros (30% Protein, 40% Carb, 30% Fat)
          const protG = Math.round((tdee * 0.30) / 4);
          const carbG = Math.round((tdee * 0.40) / 4);
          const fatG = Math.round((tdee * 0.30) / 9);

          return {
            summaryLabel: `${Math.round(tdee)} kcal/day`,
            kpis: [
              { label: 'Maintenance (TDEE)', value: `${Math.round(tdee)} kcal`, sub: `Basal BMR: ${Math.round(bmr)} kcal` },
              { label: 'Fat Loss Target (-0.5 kg/wk)', value: `${Math.round(cutCal)} kcal`, sub: `Lean Bulk: ${Math.round(bulkCal)} kcal` },
              { label: 'Daily Balanced Macros', value: `${protG}P / ${carbG}C / ${fatG}F (g)`, sub: `30% Prot • 40% Carb • 30% Fat` }
            ],
            visualHtml: `
              <div class="grid grid-cols-3 gap-2 text-center text-xs">
                <div class="p-2.5 rounded-lg bg-indigo-500/10 border border-indigo-500/30">
                  <div class="font-bold text-indigo-600 dark:text-indigo-400 text-base">${protG}g</div>
                  <div class="text-slate-500">Protein (${Math.round(tdee * 0.3)} kcal)</div>
                </div>
                <div class="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                  <div class="font-bold text-cyan-600 dark:text-cyan-400 text-base">${carbG}g</div>
                  <div class="text-slate-500">Carbs (${Math.round(tdee * 0.4)} kcal)</div>
                </div>
                <div class="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30">
                  <div class="font-bold text-amber-600 dark:text-amber-400 text-base">${fatG}g</div>
                  <div class="text-slate-500">Fats (${Math.round(tdee * 0.3)} kcal)</div>
                </div>
              </div>
            `,
            formulaSteps: [
              `Mifflin-St Jeor BMR = 10(${v.weightKg}) + 6.25(${v.heightCm}) − 5(${v.age}) ${v.sex === 'male' ? '+ 5' : '− 161'} = ${Math.round(bmr)} kcal/day`,
              `TDEE = BMR × Activity (${v.activity}) = ${Math.round(tdee)} kcal/day`,
              `Macros: Protein = (0.30 × ${Math.round(tdee)}) ÷ 4 = ${protG}g | Carbs = ${carbG}g | Fat = ${fatG}g`
            ]
          };
        }
      },
      {
        id: 'bodyfat',
        name: 'Body Fat Percentage Calculator (U.S. Navy)',
        category: 'Fitness & Health',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z"/><path d="m14.5 12.5 2-2"/><path d="m11.5 9.5 2-2"/><path d="m8.5 6.5 2-2"/><path d="m17.5 15.5 2-2"/></svg>',
        popular: false,
        desc: 'Estimate body fat percentage, fat mass, and lean body mass using circumference measurements',
        inputs: [
          { key: 'heightCm', label: 'Height (cm)', type: 'number', default: 178, min: 130, max: 230, step: 1 },
          { key: 'weightKg', label: 'Weight (kg)', type: 'number', default: 78, min: 35, max: 220, step: 0.5 },
          { key: 'waistCm', label: 'Waist Circumference (cm)', type: 'number', default: 84, min: 50, max: 180, step: 0.5 },
          { key: 'neckCm', label: 'Neck Circumference (cm)', type: 'number', default: 38, min: 25, max: 65, step: 0.5 }
        ],
        compute(v) {
          const diff = Math.max(10, v.waistCm - v.neckCm);
          const bf = Math.max(3, Math.min(55, 495 / (1.0324 - 0.19077 * Math.log10(diff) + 0.15456 * Math.log10(v.heightCm)) - 450));
          const fatMass = v.weightKg * (bf / 100);
          const leanMass = v.weightKg - fatMass;
          return {
            summaryLabel: `${bf.toFixed(1)}% Body Fat`,
            kpis: [
              { label: 'Estimated Body Fat', value: `${bf.toFixed(1)}%`, sub: `U.S. Navy Method` },
              { label: 'Lean Body Mass', value: `${leanMass.toFixed(1)} kg`, sub: `${(100 - bf).toFixed(1)}% of total weight` },
              { label: 'Total Fat Mass', value: `${fatMass.toFixed(1)} kg`, sub: `Waist-to-Height: ${(v.waistCm / v.heightCm).toFixed(2)}` }
            ],
            visualHtml: `
              <div class="w-full h-5 rounded-full overflow-hidden flex bg-slate-200 dark:bg-slate-800">
                <div style="width:${(100 - bf).toFixed(1)}%" class="bg-emerald-500 h-full" title="Lean Mass"></div>
                <div style="width:${bf.toFixed(1)}%" class="bg-amber-500 h-full" title="Fat Mass"></div>
              </div>
            `,
            formulaSteps: [
              `U.S. Navy Formula: BF% = 495 / [1.0324 − 0.19077×log₁₀(waist − neck) + 0.15456×log₁₀(height)] − 450`,
              `Fat Mass = ${v.weightKg} kg × ${bf.toFixed(1)}% = ${fatMass.toFixed(1)} kg | Lean Mass = ${leanMass.toFixed(1)} kg`
            ]
          };
        }
      },
      {
        id: 'pace',
        name: 'Running Pace, Speed & Finish Time Calculator',
        category: 'Fitness & Health',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
        popular: false,
        desc: 'Calculate min/km, min/mile, km/h speed & projected 5K, 10K, Half & Full Marathon times',
        inputs: [
          { key: 'distKm', label: 'Distance (km)', type: 'number', default: 10, min: 0.1, step: 0.5 },
          { key: 'minutes', label: 'Total Time (Minutes)', type: 'number', default: 48, min: 1, step: 1 },
          { key: 'seconds', label: 'Additional Seconds', type: 'number', default: 30, min: 0, max: 59, step: 5 }
        ],
        compute(v) {
          const totalMin = v.minutes + (v.seconds / 60);
          const paceKm = totalMin / Math.max(0.1, v.distKm);
          const paceMi = paceKm * 1.60934;
          const speedKmh = (v.distKm / totalMin) * 60;
          const fmtPace = p => {
            const m = Math.floor(p);
            const s = Math.round((p - m) * 60);
            return `${m}:${s < 10 ? '0' : ''}${s}`;
          };
          return {
            summaryLabel: `${fmtPace(paceKm)} /km`,
            kpis: [
              { label: 'Pace per Kilometer', value: `${fmtPace(paceKm)} /km`, sub: `Pace per Mile: ${fmtPace(paceMi)} /mi` },
              { label: 'Average Speed', value: `${speedKmh.toFixed(2)} km/h`, sub: `${(speedKmh / 1.60934).toFixed(2)} mph` },
              { label: 'Half Marathon Projection', value: `${Math.floor(paceKm * 21.0975)} mins`, sub: `5K Equiv: ${fmtPace(paceKm * 5)} mins` }
            ],
            visualHtml: `
              <div class="grid grid-cols-4 gap-2 text-xs text-center">
                <div class="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">5K</div><div class="font-bold">${(paceKm * 5).toFixed(1)}m</div></div>
                <div class="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">10K</div><div class="font-bold">${(paceKm * 10).toFixed(1)}m</div></div>
                <div class="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">Half (21.1K)</div><div class="font-bold">${(paceKm * 21.0975).toFixed(0)}m</div></div>
                <div class="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><div class="text-slate-500">Marathon</div><div class="font-bold">${(paceKm * 42.195 / 60).toFixed(2)}h</div></div>
              </div>
            `,
            formulaSteps: [
              `Total Minutes = ${v.minutes} + (${v.seconds}/60) = ${totalMin.toFixed(2)} min`,
              `Pace = ${totalMin.toFixed(2)} min ÷ ${v.distKm} km = ${fmtPace(paceKm)} min/km (${speedKmh.toFixed(2)} km/h)`
            ]
          };
        }
      },
      {
        id: 'idealweight',
        name: 'Ideal Weight & Frame Calculator',
        category: 'Fitness & Health',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
        popular: false,
        desc: 'Compare Devine, Robinson, Miller & Hamwi clinical ideal body weight formulas',
        inputs: [
          { key: 'sex', label: 'Sex', type: 'select', default: 'male', options: [{v: 'male', l: 'Male'}, {v: 'female', l: 'Female'}] },
          { key: 'heightCm', label: 'Height (cm)', type: 'number', default: 175, min: 140, max: 220, step: 1 }
        ],
        compute(v) {
          const inchesOver5Ft = Math.max(0, (v.heightCm / 2.54) - 60);
          const devine = (v.sex === 'male' ? 50 : 45.5) + 2.3 * inchesOver5Ft;
          const robinson = (v.sex === 'male' ? 52 : 49) + (v.sex === 'male' ? 1.9 : 1.7) * inchesOver5Ft;
          const miller = (v.sex === 'male' ? 56.2 : 53.1) + (v.sex === 'male' ? 1.41 : 1.36) * inchesOver5Ft;
          return {
            summaryLabel: `${devine.toFixed(1)} kg`,
            kpis: [
              { label: 'Devine Formula (Clinical)', value: `${devine.toFixed(1)} kg`, sub: `${(devine * 2.20462).toFixed(1)} lbs` },
              { label: 'Robinson Formula', value: `${robinson.toFixed(1)} kg`, sub: `${(robinson * 2.20462).toFixed(1)} lbs` },
              { label: 'Miller Formula', value: `${miller.toFixed(1)} kg`, sub: `${(miller * 2.20462).toFixed(1)} lbs` }
            ],
            visualHtml: `
              <div class="text-xs text-slate-600 dark:text-slate-300">Height: <strong>${v.heightCm} cm</strong> (${inchesOver5Ft.toFixed(1)} inches above 5 ft)</div>
            `,
            formulaSteps: [
              `Devine Formula: Base (${v.sex === 'male' ? '50' : '45.5'} kg) + 2.3 kg × inches over 60" = ${devine.toFixed(1)} kg`
            ]
          };
        }
      },

      // ---------------- MATH & GRAPHING (6) ----------------
      {
        id: 'graphing',
        name: 'Interactive Function Graphing Calculator',
        category: 'Math',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
        popular: true,
        desc: 'Plot f(x) = a·sin(b·x) + c·x² + d·x + e with live root/extremum inspection (Desmos-inspired)',
        inputs: [
          { key: 'quadA', label: 'Quadratic Coeff (c · x²)', type: 'number', default: 0.25, min: -5, max: 5, step: 0.05 },
          { key: 'linB', label: 'Linear Coeff (d · x)', type: 'number', default: -0.5, min: -10, max: 10, step: 0.25 },
          { key: 'constC', label: 'Constant Offset (e)', type: 'number', default: -1.5, min: -10, max: 10, step: 0.5 },
          { key: 'sinAmp', label: 'Sine Wave Amplitude (a · sin(x))', type: 'number', default: 1.2, min: -5, max: 5, step: 0.2 },
          { key: 'evalX', label: 'Evaluate at x =', type: 'number', default: 2.0, min: -10, max: 10, step: 0.5 }
        ],
        compute(v) {
          const f = x => (v.sinAmp * Math.sin(x)) + (v.quadA * x * x) + (v.linB * x) + v.constC;
          const yAtX = f(v.evalX);
          const h = 0.0001;
          const slopeAtX = (f(v.evalX + h) - f(v.evalX - h)) / (2 * h);
          const yIntercept = f(0);

          // Build SVG coordinate plot from x = -8 to +8
          const pts = [];
          for (let px = 0; px <= 320; px += 4) {
            const x = -8 + (px / 320) * 16;
            const y = f(x);
            const py = 75 - Math.max(-70, Math.min(70, y * 8));
            pts.push(`${px},${py.toFixed(1)}`);
          }
          const markerPx = ((v.evalX + 8) / 16) * 320;
          const markerPy = 75 - Math.max(-70, Math.min(70, yAtX * 8));

          return {
            summaryLabel: `f(${v.evalX}) = ${yAtX.toFixed(3)}`,
            kpis: [
              { label: `Value at x = ${v.evalX}`, value: `f(${v.evalX}) = ${yAtX.toFixed(3)}`, sub: `Coordinate: (${v.evalX}, ${yAtX.toFixed(2)})` },
              { label: `Derivative f'(${v.evalX})`, value: slopeAtX.toFixed(3), sub: `Instantaneous tangent slope` },
              { label: 'Y-Intercept f(0)', value: yIntercept.toFixed(3), sub: `Domain plotted: [−8, +8]` }
            ],
            visualHtml: `
              <div class="bg-slate-900 rounded-lg p-3 text-white">
                <svg viewBox="0 0 320 150" class="w-full h-40 overflow-visible">
                  <line x1="0" y1="75" x2="320" y2="75" stroke="#475569" stroke-width="1" />
                  <line x1="160" y1="0" x2="160" y2="150" stroke="#475569" stroke-width="1" />
                  <polyline fill="none" stroke="#38bdf8" stroke-width="2.5" points="${pts.join(' ')}" />
                  <circle cx="${markerPx.toFixed(1)}" cy="${markerPy.toFixed(1)}" r="4.5" fill="#f43f5e" stroke="#fff" stroke-width="1.5" />
                </svg>
                <div class="flex justify-between text-[11px] text-slate-400 font-mono-num mt-1">
                  <span>x = −8</span>
                  <span class="text-cyan-400">f(x) = ${v.sinAmp}·sin(x) + ${v.quadA}x² + ${v.linB}x + ${v.constC}</span>
                  <span>x = +8</span>
                </div>
              </div>
            `,
            formulaSteps: [
              `Function: f(x) = ${v.sinAmp}·sin(x) + ${v.quadA}·x² + (${v.linB})·x + (${v.constC})`,
              `f(${v.evalX}) = ${(v.sinAmp * Math.sin(v.evalX)).toFixed(3)} + ${(v.quadA * v.evalX * v.evalX).toFixed(3)} + ${(v.linB * v.evalX).toFixed(3)} + (${v.constC}) = ${yAtX.toFixed(4)}`,
              `Numerical Derivative f'(${v.evalX}) ≈ ${slopeAtX.toFixed(4)}`
            ]
          };
        }
      },
      {
        id: 'percentage',
        name: '3-in-1 Percentage Calculator',
        category: 'Math',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>',
        popular: true,
        desc: 'Simultaneously solve X% of Y, what % X is of Y, and percentage increase/decrease',
        inputs: [
          { key: 'valX', label: 'Value X (Percentage or Part)', type: 'number', default: 18, step: 1 },
          { key: 'valY', label: 'Value Y (Base Value)', type: 'number', default: 250, step: 10 }
        ],
        compute(v) {
          const pctOf = (v.valX / 100) * v.valY;
          const whatPct = v.valY !== 0 ? (v.valX / v.valY) * 100 : 0;
          const pctChange = v.valX !== 0 ? ((v.valY - v.valX) / Math.abs(v.valX)) * 100 : 0;
          return {
            summaryLabel: `${v.valX}% of ${v.valY} = ${fmtNum(pctOf, 2)}`,
            kpis: [
              { label: `${v.valX}% of ${v.valY}`, value: fmtNum(pctOf, 3), sub: `After ${v.valX}% Discount: ${fmtNum(v.valY - pctOf, 2)}` },
              { label: `${v.valX} is what % of ${v.valY}?`, value: `${whatPct.toFixed(2)}%`, sub: `Ratio: ${(v.valX / Math.max(1, v.valY)).toFixed(4)}` },
              { label: `% Change (${v.valX} → ${v.valY})`, value: `${pctChange >= 0 ? '+' : ''}${pctChange.toFixed(2)}%`, sub: `Difference: ${fmtNum(v.valY - v.valX, 2)}` }
            ],
            visualHtml: `
              <div class="grid grid-cols-2 gap-2 text-xs">
                <div class="p-2.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><strong>${v.valY} + ${v.valX}%</strong> = ${fmtNum(v.valY + pctOf, 2)}</div>
                <div class="p-2.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"><strong>${v.valY} − ${v.valX}%</strong> = ${fmtNum(v.valY - pctOf, 2)}</div>
              </div>
            `,
            formulaSteps: [
              `1) ${v.valX}% of ${v.valY} = (${v.valX} ÷ 100) × ${v.valY} = ${fmtNum(pctOf, 4)}`,
              `2) (${v.valX} ÷ ${v.valY}) × 100 = ${whatPct.toFixed(2)}%`,
              `3) Percentage Change = [(${v.valY} − ${v.valX}) ÷ |${v.valX}|] × 100 = ${pctChange.toFixed(2)}%`
            ]
          };
        }
      },
      {
        id: 'fraction',
        name: 'Step-by-Step Fraction Calculator',
        category: 'Math',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="6" r="1.5"/><line x1="5" y1="12" x2="19" y2="12"/><circle cx="12" cy="18" r="1.5"/></svg>',
        popular: false,
        desc: 'Add, subtract, multiply & divide fractions with greatest common divisor (GCD) reduction',
        inputs: [
          { key: 'n1', label: 'First Numerator (a)', type: 'number', default: 3, step: 1 },
          { key: 'd1', label: 'First Denominator (b)', type: 'number', default: 4, step: 1 },
          { key: 'op', label: 'Operation', type: 'select', default: '+', options: [{v: '+', l: 'Add (+)'}, {v: '-', l: 'Subtract (−)'}, {v: '*', l: 'Multiply (×)'}, {v: '/', l: 'Divide (÷)'}] },
          { key: 'n2', label: 'Second Numerator (c)', type: 'number', default: 5, step: 1 },
          { key: 'd2', label: 'Second Denominator (d)', type: 'number', default: 6, step: 1 }
        ],
        compute(v) {
          const b = v.d1 === 0 ? 1 : v.d1;
          const d = v.d2 === 0 ? 1 : v.d2;
          let rawN = 0, rawD = b * d;
          if (v.op === '+') rawN = v.n1 * d + v.n2 * b;
          else if (v.op === '-') rawN = v.n1 * d - v.n2 * b;
          else if (v.op === '*') { rawN = v.n1 * v.n2; rawD = b * d; }
          else if (v.op === '/') { rawN = v.n1 * d; rawD = b * (v.n2 === 0 ? 1 : v.n2); }

          const gcd = (x, y) => { x = Math.abs(x); y = Math.abs(y); while (y) { const t = y; y = x % y; x = t; } return x || 1; };
          const g = gcd(rawN, rawD);
          const sign = rawD < 0 ? -1 : 1;
          const simpN = (rawN / g) * sign;
          const simpD = Math.abs(rawD / g);
          const decVal = simpN / simpD;

          return {
            summaryLabel: `${simpN}/${simpD}`,
            kpis: [
              { label: 'Simplified Fraction', value: `${simpN} / ${simpD}`, sub: `GCD Divided by ${g}` },
              { label: 'Decimal Equivalent', value: decVal.toFixed(5), sub: `Percentage: ${(decVal * 100).toFixed(2)}%` },
              { label: 'Unreduced Result', value: `${rawN} / ${rawD}`, sub: `Input: ${v.n1}/${b} ${v.op} ${v.n2}/${d}` }
            ],
            visualHtml: `
              <div class="text-center font-mono-num text-sm p-2 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800">
                (${v.n1}/${b}) ${v.op} (${v.n2}/${d}) = <strong>${rawN}/${rawD}</strong> = <strong class="text-indigo-600 dark:text-indigo-400">${simpN}/${simpD}</strong>
              </div>
            `,
            formulaSteps: [
              `Step 1 (Combine): (${v.n1}/${b}) ${v.op} (${v.n2}/${d}) = ${rawN}/${rawD}`,
              `Step 2 (Find GCD): GCD(|${rawN}|, |${rawD}|) = ${g}`,
              `Step 3 (Reduce): (${rawN} ÷ ${g}) / (${rawD} ÷ ${g}) = ${simpN}/${simpD} (${decVal.toFixed(4)})`
            ]
          };
        }
      },
      {
        id: 'statistics',
        name: 'Standard Deviation & Statistics Calculator',
        category: 'Math',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
        popular: false,
        desc: 'Compute mean, median, variance, sample & population standard deviation from a dataset',
        inputs: [
          { key: 'dataset', label: 'Comma-Separated Numbers', type: 'text', default: '12, 15, 18, 22, 24, 29, 31, 35' }
        ],
        compute(v) {
          const arr = String(v.dataset).split(/[\s,]+/).map(Number).filter(n => isFinite(n));
          const nums = arr.length > 0 ? arr : [0];
          const n = nums.length;
          const sum = nums.reduce((a, b) => a + b, 0);
          const mean = sum / n;
          const sorted = nums.slice().sort((a, b) => a - b);
          const median = n % 2 === 1 ? sorted[Math.floor(n / 2)] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
          const sqDiff = nums.reduce((acc, x) => acc + Math.pow(x - mean, 2), 0);
          const popSD = Math.sqrt(sqDiff / n);
          const sampSD = n > 1 ? Math.sqrt(sqDiff / (n - 1)) : 0;

          return {
            summaryLabel: `Mean ${mean.toFixed(2)} | SD ${sampSD.toFixed(2)}`,
            kpis: [
              { label: 'Mean (Average)', value: mean.toFixed(3), sub: `Median: ${median.toFixed(2)} | Sum: ${sum}` },
              { label: 'Sample Std Dev (s)', value: sampSD.toFixed(4), sub: `Sample Variance: ${(sampSD * sampSD).toFixed(3)}` },
              { label: 'Population Std Dev (σ)', value: popSD.toFixed(4), sub: `Count (n): ${n} | Range: ${sorted[0]} to ${sorted[n - 1]}` }
            ],
            visualHtml: `
              <div class="text-xs font-mono-num">Sorted Data (n=${n}): [${sorted.join(', ')}]</div>
            `,
            formulaSteps: [
              `Mean (μ) = Σx ÷ n = ${sum} ÷ ${n} = ${mean.toFixed(4)}`,
              `Sum of Squared Deviations Σ(xᵢ − μ)² = ${sqDiff.toFixed(4)}`,
              `Sample SD (s) = √[${sqDiff.toFixed(3)} ÷ (${n} − 1)] = ${sampSD.toFixed(4)} | Population SD (σ) = ${popSD.toFixed(4)}`
            ]
          };
        }
      },
      {
        id: 'quadratic',
        name: 'Quadratic Equation & Discriminant Solver',
        category: 'Math',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>',
        popular: false,
        desc: 'Solve ax² + bx + c = 0 for real or complex roots, vertex coordinates & discriminant Δ',
        inputs: [
          { key: 'a', label: 'Coefficient a (x²)', type: 'number', default: 2, step: 1 },
          { key: 'b', label: 'Coefficient b (x)', type: 'number', default: -7, step: 1 },
          { key: 'c', label: 'Constant c', type: 'number', default: 3, step: 1 }
        ],
        compute(v) {
          const a = v.a === 0 ? 1 : v.a;
          const disc = (v.b * v.b) - (4 * a * v.c);
          const vx = -v.b / (2 * a);
          const vy = a * vx * vx + v.b * vx + v.c;
          let rootsText = '';
          if (disc >= 0) {
            const r1 = (-v.b + Math.sqrt(disc)) / (2 * a);
            const r2 = (-v.b - Math.sqrt(disc)) / (2 * a);
            rootsText = `x₁ = ${r1.toFixed(4)}, x₂ = ${r2.toFixed(4)}`;
          } else {
            const realP = (-v.b / (2 * a)).toFixed(3);
            const imagP = (Math.sqrt(-disc) / (2 * a)).toFixed(3);
            rootsText = `${realP} ± ${imagP}i`;
          }
          return {
            summaryLabel: rootsText,
            kpis: [
              { label: 'Roots (Solutions)', value: rootsText, sub: disc >= 0 ? 'Real Roots' : 'Complex Conjugate Roots' },
              { label: 'Discriminant (Δ = b²−4ac)', value: String(disc), sub: disc > 0 ? 'Δ > 0 (Two Distinct Real)' : (disc === 0 ? 'Δ = 0 (One Repeated)' : 'Δ < 0 (Complex)') },
              { label: 'Parabola Vertex (h, k)', value: `(${vx.toFixed(2)}, ${vy.toFixed(2)})`, sub: `Axis of Symmetry: x = ${vx.toFixed(2)}` }
            ],
            visualHtml: `<div class="text-xs font-mono-num">Equation: ${a}x² + (${v.b})x + (${v.c}) = 0 → ${rootsText}</div>`,
            formulaSteps: [
              `Quadratic Formula: x = [−b ± √(b² − 4ac)] ÷ 2a`,
              `Discriminant Δ = (${v.b})² − 4(${a})(${v.c}) = ${disc}`,
              `Solutions: ${rootsText}`
            ]
          };
        }
      },
      {
        id: 'triangle',
        name: 'Right Triangle & Trigonometry Calculator',
        category: 'Math',
        icon: '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z"/><path d="m14.5 12.5 2-2"/><path d="m11.5 9.5 2-2"/><path d="m8.5 6.5 2-2"/><path d="m17.5 15.5 2-2"/></svg>',
        popular: false,
        desc: 'Solve hypotenuse, area, perimeter, and interior angles from two legs a and b',
        inputs: [
          { key: 'sideA', label: 'Side a (Base)', type: 'number', default: 6, min: 0.1, step: 0.5 },
          { key: 'sideB', label: 'Side b (Height)', type: 'number', default: 8, min: 0.1, step: 0.5 }
        ],
        compute(v) {
          const c = Math.hypot(v.sideA, v.sideB);
          const area = 0.5 * v.sideA * v.sideB;
          const angleA = (Math.atan2(v.sideA, v.sideB) * 180) / Math.PI;
          const angleB = 90 - angleA;
          return {
            summaryLabel: `c = ${c.toFixed(3)}`,
            kpis: [
              { label: 'Hypotenuse (c)', value: c.toFixed(4), sub: `Perimeter: ${(v.sideA + v.sideB + c).toFixed(2)}` },
              { label: 'Triangle Area', value: area.toFixed(3), sub: `½ × ${v.sideA} × ${v.sideB}` },
              { label: 'Acute Angles (α, β)', value: `${angleA.toFixed(1)}° & ${angleB.toFixed(1)}°`, sub: `Right Angle = 90°` }
            ],
            visualHtml: `<div class="text-xs">Pythagorean Theorem: ${v.sideA}² + ${v.sideB}² = ${c.toFixed(2)}² (${(v.sideA*v.sideA + v.sideB*v.sideB).toFixed(2)})</div>`,
            formulaSteps: [
              `c = √(a² + b²) = √(${v.sideA}² + ${v.sideB}²) = ${c.toFixed(4)}`,
              `Area = ½ × a × b = ${area.toFixed(3)} | α = arctan(a/b) = ${angleA.toFixed(2)}°`
            ]
          };
        }
      },

      // ---------------- SCIENCE & UTILITY (6) ----------------
      {
        id: 'unit',
        name: 'Universal Unit Converter',
        category: 'Science & Utility',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
        popular: true,
        desc: 'Convert Length, Weight/Mass, Temperature, Volume & Speed simultaneously',
        inputs: [
          { key: 'val', label: 'Input Value', type: 'number', default: 100, step: 1 },
          { key: 'mode', label: 'Conversion Type', type: 'select', default: 'length', options: [
            {v: 'length', l: 'Length (km ⇄ miles, m ⇄ ft)'},
            {v: 'weight', l: 'Weight (kg ⇄ lbs, g ⇄ oz)'},
            {v: 'temp', l: 'Temperature (°C ⇄ °F ⇄ K)'},
            {v: 'speed', l: 'Speed (km/h ⇄ mph ⇄ m/s)'}
          ]}
        ],
        compute(v) {
          const x = v.val;
          if (v.mode === 'length') {
            return {
              summaryLabel: `${x} km = ${(x * 0.621371).toFixed(2)} mi`,
              kpis: [
                { label: 'Kilometers → Miles', value: `${(x * 0.621371).toFixed(3)} mi`, sub: `${x} mi = ${(x * 1.60934).toFixed(3)} km` },
                { label: 'Meters → Feet', value: `${(x * 3.28084).toFixed(3)} ft`, sub: `${x} ft = ${(x * 0.3048).toFixed(3)} m` },
                { label: 'Centimeters → Inches', value: `${(x * 0.393701).toFixed(3)} in`, sub: `${x} in = ${(x * 2.54).toFixed(3)} cm` }
              ],
              visualHtml: `<div class="text-xs">${x} meters = ${(x * 100).toLocaleString()} cm = ${(x * 39.3701).toFixed(1)} inches</div>`,
              formulaSteps: [`1 km = 0.621371 miles | 1 meter = 3.28084 feet | 1 inch = 2.54 cm`]
            };
          } else if (v.mode === 'weight') {
            return {
              summaryLabel: `${x} kg = ${(x * 2.20462).toFixed(2)} lbs`,
              kpis: [
                { label: 'Kilograms → Pounds', value: `${(x * 2.20462).toFixed(3)} lbs`, sub: `${x} lbs = ${(x * 0.453592).toFixed(3)} kg` },
                { label: 'Grams → Ounces', value: `${(x * 0.035274).toFixed(3)} oz`, sub: `${x} oz = ${(x * 28.3495).toFixed(2)} g` },
                { label: 'Kilograms → Stone', value: `${(x * 0.157473).toFixed(3)} st`, sub: `1 stone = 14 lbs` }
              ],
              visualHtml: `<div class="text-xs">${x} kg = ${(x * 1000).toLocaleString()} g = ${(x * 2.20462).toFixed(2)} lbs</div>`,
              formulaSteps: [`1 kg = 2.20462262 lbs | 1 oz = 28.34952 g`]
            };
          } else if (v.mode === 'temp') {
            const cToF = (x * 9 / 5) + 32;
            const fToC = (x - 32) * 5 / 9;
            return {
              summaryLabel: `${x}°C = ${cToF.toFixed(1)}°F`,
              kpis: [
                { label: `${x} °C to Fahrenheit`, value: `${cToF.toFixed(2)} °F`, sub: `Kelvin: ${(x + 273.15).toFixed(2)} K` },
                { label: `${x} °F to Celsius`, value: `${fToC.toFixed(2)} °C`, sub: `Kelvin: ${(fToC + 273.15).toFixed(2)} K` },
                { label: 'Boiling / Freezing Ref', value: `100°C / 0°C`, sub: `212°F / 32°F` }
              ],
              visualHtml: `<div class="text-xs">${x}°C equals ${cToF.toFixed(2)}°F and ${(x + 273.15).toFixed(2)} Kelvin</div>`,
              formulaSteps: [`°F = (°C × 9/5) + 32 | °C = (°F − 32) × 5/9 | K = °C + 273.15`]
            };
          }
          return {
            summaryLabel: `${x} km/h = ${(x * 0.621371).toFixed(2)} mph`,
            kpis: [
              { label: 'km/h → mph', value: `${(x * 0.621371).toFixed(2)} mph`, sub: `${x} mph = ${(x * 1.60934).toFixed(2)} km/h` },
              { label: 'km/h → m/s', value: `${(x / 3.6).toFixed(2)} m/s`, sub: `${x} m/s = ${(x * 3.6).toFixed(2)} km/h` },
              { label: 'Knots Equivalent', value: `${(x * 0.539957).toFixed(2)} kn`, sub: `1 knot = 1.852 km/h` }
            ],
            visualHtml: `<div class="text-xs">${x} km/h = ${(x / 3.6).toFixed(2)} meters/second</div>`,
            formulaSteps: [`m/s = km/h ÷ 3.6 | mph = km/h × 0.621371`]
          };
        }
      },
      {
        id: 'ohms',
        name: "Ohm's Law & Electrical Power Calculator",
        category: 'Science & Utility',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
        popular: false,
        desc: 'Calculate Current (I), Power (Watts), and daily kWh energy from Voltage (V) & Resistance (Ω)',
        inputs: [
          { key: 'voltage', label: 'Voltage V (Volts)', type: 'number', default: 120, min: 0.1, step: 5 },
          { key: 'resistance', label: 'Resistance R (Ohms Ω)', type: 'number', default: 24, min: 0.01, step: 1 }
        ],
        compute(v) {
          const current = v.voltage / Math.max(0.0001, v.resistance);
          const watts = v.voltage * current;
          const kwhDay = (watts * 24) / 1000;
          return {
            summaryLabel: `${current.toFixed(2)} A | ${watts.toFixed(1)} W`,
            kpis: [
              { label: 'Current (I = V / R)', value: `${current.toFixed(3)} Amps`, sub: `At ${v.voltage}V across ${v.resistance}Ω` },
              { label: 'Electrical Power (P)', value: `${watts.toFixed(2)} Watts`, sub: `${(watts / 1000).toFixed(3)} kW` },
              { label: '24-Hour Energy Use', value: `${kwhDay.toFixed(2)} kWh/day`, sub: `At $0.15/kWh: ${fmtCurrency(kwhDay * 0.15)}/day` }
            ],
            visualHtml: `<div class="text-xs font-mono-num">V = I × R (${v.voltage}V = ${current.toFixed(2)}A × ${v.resistance}Ω) | P = V × I = ${watts.toFixed(1)}W</div>`,
            formulaSteps: [
              `Current I = V ÷ R = ${v.voltage} ÷ ${v.resistance} = ${current.toFixed(4)} A`,
              `Power P = V × I = ${v.voltage} × ${current.toFixed(4)} = ${watts.toFixed(2)} W`
            ]
          };
        }
      },
      {
        id: 'age',
        name: 'Exact Age & Date Duration Calculator',
        category: 'Science & Utility',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
        popular: false,
        desc: 'Compute exact years, months, days, total weeks & hours between full calendar dates',
        inputs: [
          { key: 'startDate', label: 'Start / Birth Date (Day, Month, Year)', type: 'date', default: '1996-05-15' },
          {
            key: 'endDate',
            label: "End / Target Date (Today's Full Date by Default)",
            type: 'date',
            default: () => {
              const now = new Date();
              const y = now.getFullYear();
              const m = String(now.getMonth() + 1).padStart(2, '0');
              const d = String(now.getDate()).padStart(2, '0');
              return `${y}-${m}-${d}`;
            }
          }
        ],
        compute(v) {
          const parseLocal = str => {
            const parts = String(str || '').split('-').map(Number);
            if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
              return new Date(parts[0], parts[1] - 1, parts[2]);
            }
            return new Date();
          };
          let d1 = parseLocal(v.startDate);
          let d2 = parseLocal(v.endDate);
          if (d1 > d2) { const tmp = d1; d1 = d2; d2 = tmp; }

          let yrs = d2.getFullYear() - d1.getFullYear();
          let mos = d2.getMonth() - d1.getMonth();
          let days = d2.getDate() - d1.getDate();

          if (days < 0) {
            const prevMonthDays = new Date(d2.getFullYear(), d2.getMonth(), 0).getDate();
            days += prevMonthDays;
            mos -= 1;
          }
          if (mos < 0) {
            mos += 12;
            yrs -= 1;
          }

          const totalDays = Math.round(Math.abs(d2 - d1) / (1000 * 60 * 60 * 24));
          const totalWeeks = Math.floor(totalDays / 7);
          const remDays = totalDays % 7;
          const fmtDate = dt => dt.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

          return {
            summaryLabel: `${yrs} yrs, ${mos} mos, ${days} days`,
            kpis: [
              { label: 'Exact Age / Duration', value: `${yrs}y ${mos}m ${days}d`, sub: `${fmtDate(d1)} → ${fmtDate(d2)}` },
              { label: 'Total Days & Weeks', value: `${totalDays.toLocaleString()} days`, sub: `${totalWeeks.toLocaleString()} weeks, ${remDays} days` },
              { label: 'Total Hours & Minutes', value: `${(totalDays * 24).toLocaleString()} hrs`, sub: `${(totalDays * 1440).toLocaleString()} minutes` }
            ],
            visualHtml: `<div class="text-xs space-y-1"><div><strong>Start Date:</strong> ${fmtDate(d1)} &nbsp;|&nbsp; <strong>End Date:</strong> ${fmtDate(d2)}</div><div>Total span equals <strong>${totalDays.toLocaleString()}</strong> calendar days (${(totalDays / 365.2425).toFixed(2)} solar years).</div></div>`,
            formulaSteps: [
              `Start Date: ${fmtDate(d1)} | End / Target Date: ${fmtDate(d2)}`,
              `Exact Calendar Span = ${yrs} Years, ${mos} Months, ${days} Days`,
              `Total Days = |End Date − Start Date| ÷ 86,400,000 ms = ${totalDays.toLocaleString()} days`
            ]
          };
        }
      },
      {
        id: 'gpa',
        name: 'GPA & Weighted Grade Calculator',
        category: 'Science & Utility',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>',
        popular: false,
        desc: 'Calculate semester GPA and cumulative GPA on a 4.0 scale',
        inputs: [
          { key: 'curGpa', label: 'Current Cumulative GPA', type: 'number', default: 3.45, min: 0, max: 4.0, step: 0.05 },
          { key: 'curCredits', label: 'Completed Credits', type: 'number', default: 60, min: 0, step: 3 },
          { key: 'semGpa', label: 'This Semester GPA', type: 'number', default: 3.85, min: 0, max: 4.0, step: 0.05 },
          { key: 'semCredits', label: 'Semester Credits', type: 'number', default: 15, min: 1, step: 3 }
        ],
        compute(v) {
          const totalPts = (v.curGpa * v.curCredits) + (v.semGpa * v.semCredits);
          const totalCred = Math.max(1, v.curCredits + v.semCredits);
          const newGpa = totalPts / totalCred;
          return {
            summaryLabel: `${newGpa.toFixed(3)} GPA`,
            kpis: [
              { label: 'New Cumulative GPA', value: newGpa.toFixed(3), sub: `Change: ${(newGpa - v.curGpa) >= 0 ? '+' : ''}${(newGpa - v.curGpa).toFixed(3)}` },
              { label: 'Total Credits Earned', value: String(totalCred), sub: `${v.curCredits} prior + ${v.semCredits} current` },
              { label: 'Total Grade Points', value: totalPts.toFixed(1), sub: `4.0 Standard Scale` }
            ],
            visualHtml: `<div class="text-xs">Quality Points: ${(v.curGpa * v.curCredits).toFixed(1)} (past) + ${(v.semGpa * v.semCredits).toFixed(1)} (semester) = ${totalPts.toFixed(1)} pts</div>`,
            formulaSteps: [`Cumulative GPA = (${v.curGpa}×${v.curCredits} + ${v.semGpa}×${v.semCredits}) ÷ (${v.curCredits} + ${v.semCredits}) = ${newGpa.toFixed(3)}`]
          };
        }
      },
      {
        id: 'subnet',
        name: 'IPv4 CIDR & Subnet Calculator',
        category: 'Science & Utility',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
        popular: false,
        desc: 'Calculate subnet mask, total IP addresses, usable hosts & wildcard mask from CIDR prefix',
        inputs: [
          { key: 'cidr', label: 'CIDR Prefix Length (/8 to /32)', type: 'number', default: 24, min: 8, max: 32, step: 1 }
        ],
        compute(v) {
          const p = Math.min(32, Math.max(8, Math.round(v.cidr)));
          const totalIps = Math.pow(2, 32 - p);
          const usable = p >= 31 ? totalIps : Math.max(0, totalIps - 2);
          const maskNum = p === 0 ? 0 : (~0 << (32 - p)) >>> 0;
          const octets = [(maskNum >>> 24) & 255, (maskNum >>> 16) & 255, (maskNum >>> 8) & 255, maskNum & 255];
          const maskStr = octets.join('.');
          const wildStr = octets.map(o => 255 - o).join('.');
          return {
            summaryLabel: `/${p} (${usable.toLocaleString()} hosts)`,
            kpis: [
              { label: 'Subnet Mask', value: maskStr, sub: `Wildcard: ${wildStr}` },
              { label: 'Usable Host IPs', value: usable.toLocaleString(), sub: `Total Addresses: ${totalIps.toLocaleString()}` },
              { label: 'Host Bits (32 − CIDR)', value: `${32 - p} bits`, sub: `Network Bits: ${p}` }
            ],
            visualHtml: `<div class="text-xs font-mono-num">Prefix /${p} → Mask ${maskStr} → 2^${32 - p} − 2 = ${usable.toLocaleString()} usable hosts</div>`,
            formulaSteps: [`Total IPs = 2^(32 − ${p}) = ${totalIps.toLocaleString()} | Usable Hosts = ${usable.toLocaleString()}`]
          };
        }
      },
      {
        id: 'password',
        name: 'Cryptographic Password & Entropy Calculator',
        category: 'Science & Utility',
        icon: '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
        popular: false,
        desc: 'Generate strong random passwords and calculate bit entropy & brute-force resistance',
        inputs: [
          { key: 'length', label: 'Password Length', type: 'number', default: 16, min: 6, max: 64, step: 1 },
          { key: 'poolSize', label: 'Character Pool', type: 'select', default: 94, options: [
            {v: 94, l: 'Upper + Lower + Digits + Symbols (94 chars)'},
            {v: 62, l: 'Alphanumeric Upper + Lower + Digits (62 chars)'},
            {v: 36, l: 'Lowercase + Digits (36 chars)'}
          ]}
        ],
        compute(v) {
          const len = Math.max(4, Math.min(64, Math.round(v.length)));
          const pool = Number(v.poolSize);
          const entropy = len * Math.log2(pool);
          const chars = pool === 94
            ? 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*()-_=+'
            : (pool === 62 ? 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789' : 'abcdefghijkmnopqrstuvwxyz0123456789');
          let sample = '';
          for (let i = 0; i < len; i++) {
            sample += chars.charAt((i * 17 + len * 13 + pool) % chars.length);
          }
          const strength = entropy >= 80 ? 'Very Strong (Military Grade)' : (entropy >= 60 ? 'Strong' : 'Moderate');
          return {
            summaryLabel: `${entropy.toFixed(1)} bits`,
            kpis: [
              { label: 'Information Entropy', value: `${entropy.toFixed(1)} bits`, sub: strength },
              { label: 'Keyspace Combinations', value: `2^${Math.round(entropy)}`, sub: `Pool: ${pool} chars, Length: ${len}` },
              { label: 'Sample Generated Key', value: sample.slice(0, 18), sub: `Click Copy Steps to copy` }
            ],
            visualHtml: `<div class="text-xs font-mono-num break-all p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">Sample: <strong>${sample}</strong></div>`,
            formulaSteps: [`Entropy E = Length × log₂(Pool Size) = ${len} × log₂(${pool}) = ${entropy.toFixed(2)} bits`, `Sample Key: ${sample}`]
          };
        }
      }
    ];

    // =========================================================================
    // 4. APPLICATION STATE & RENDERING
    // =========================================================================
    const appState = {
      activeCalcId: 'mortgage',
      activeCategoryFilter: 'all',
      inputValues: {},
      favorites: safeGetStorage('calcverse_favorites', ['mortgage', 'bmi', 'compound', 'graphing']),
      pins: safeGetStorage('calcverse_pins', []),
      history: safeGetStorage('calcverse_history', []),
      lastResult: null
    };

    function getActiveCalc() {
      return CALCULATORS.find(c => c.id === appState.activeCalcId) || CALCULATORS[0];
    }

    function initCalcDefaults(calc, forceReset = false) {
      if (!appState.inputValues[calc.id] || forceReset) {
        const defaults = {};
        calc.inputs.forEach(inp => {
          defaults[inp.key] = typeof inp.default === 'function' ? inp.default() : inp.default;
        });
        appState.inputValues[calc.id] = defaults;
      }
    }

    function selectCalculator(calcId, scrollToWorkspace = false) {
      const target = CALCULATORS.find(c => c.id === calcId);
      if (!target) return;
      appState.activeCalcId = target.id;
      initCalcDefaults(target, false);
      renderActiveWorkspace();
      if (scrollToWorkspace) {
        document.getElementById('activeCalculatorWorkspace').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }

    function renderActiveWorkspace() {
      const calc = getActiveCalc();
      initCalcDefaults(calc, false);
      const vals = appState.inputValues[calc.id];

      document.getElementById('activeCalcIcon').innerHTML = calc.icon;
      document.getElementById('activeCalcCategoryBadge').textContent = calc.category;
      document.getElementById('activeCalcTitle').textContent = calc.name;
      document.getElementById('activeCalcSubtitle').textContent = calc.desc;

      const isFav = appState.favorites.includes(calc.id);
      document.getElementById('favCurrentStar').innerHTML = '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
      document.getElementById('favCurrentStar').classList.toggle('text-amber-500', isFav);
      document.getElementById('favCurrentText').textContent = isFav ? 'Saved' : 'Save Tool';

      // Build Inputs
      const inputsContainer = document.getElementById('calcInputsContainer');
      inputsContainer.innerHTML = calc.inputs.map(inp => {
        const curVal = vals[inp.key];
        if (inp.type === 'select') {
          return `
            <div>
              <label class="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">${inp.label}</label>
              <select data-calc-input="${inp.key}" class="w-full px-3 py-2 rounded-lg text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                ${inp.options.map(opt => `<option value="${opt.v}" ${String(opt.v) === String(curVal) ? 'selected' : ''}>${opt.l}</option>`).join('')}
              </select>
            </div>
          `;
        }
        return `
          <div>
            <label class="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">${inp.label}</label>
            <input type="${inp.type}" data-calc-input="${inp.key}" value="${curVal}" ${inp.min !== undefined ? `min="${inp.min}"` : ''} ${inp.max !== undefined ? `max="${inp.max}"` : ''} ${inp.step !== undefined ? `step="${inp.step}"` : ''} class="w-full px-3 py-2 rounded-lg text-sm font-mono-num bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
          </div>
        `;
      }).join('');

      inputsContainer.querySelectorAll('[data-calc-input]').forEach(el => {
        el.addEventListener('input', () => {
          const key = el.getAttribute('data-calc-input');
          const def = calc.inputs.find(i => i.key === key);
          if (def && def.type === 'number') {
            const parsed = parseFloat(el.value);
            vals[key] = isFinite(parsed) ? parsed : 0;
          } else {
            vals[key] = el.value;
          }
          updateActiveCalculationOutput();
        });
      });

      updateActiveCalculationOutput();
    }

    function updateActiveCalculationOutput() {
      const calc = getActiveCalc();
      const vals = appState.inputValues[calc.id];
      const res = calc.compute(vals);
      appState.lastResult = { calc, vals: { ...vals }, res };

      document.getElementById('calcPrimaryOutput').innerHTML = res.kpis.map((k, i) => `
        <div class="p-4 rounded-xl border ${i === 0 ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' : 'bg-slate-50 dark:bg-slate-950/60 border-slate-200/80 dark:border-slate-800'}">
          <div class="text-[11px] font-semibold uppercase tracking-wider ${i === 0 ? 'text-indigo-100' : 'text-slate-500 dark:text-slate-400'}">${k.label}</div>
          <div class="text-lg sm:text-xl font-extrabold font-mono-num mt-1">${k.value}</div>
          <div class="text-xs mt-1 ${i === 0 ? 'text-indigo-100/90' : 'text-slate-500 dark:text-slate-400'}">${k.sub}</div>
        </div>
      `).join('');

      document.getElementById('calcVisualContainer').innerHTML = res.visualHtml;
      document.getElementById('calcFormulaContainer').innerHTML = res.formulaSteps.map(s => `<div>• ${s}</div>`).join('');
    }

    // =========================================================================
    // 5. DIRECTORY, POPULAR GRID, FAVORITES & PINBOARD RENDERING
    // =========================================================================
    function renderPopularQuickGrid() {
      const pop = CALCULATORS.filter(c => c.popular);
      const grid = document.getElementById('popularQuickGrid');
      grid.innerHTML = pop.map(c => `
        <button type="button" data-open-calc="${c.id}" class="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-500 dark:hover:border-indigo-500 bg-slate-50/70 dark:bg-slate-800/40 text-left transition group">
          <div class="flex items-center gap-2">
            <span class="text-base">${c.icon}</span>
            <span class="text-xs font-bold group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate">${c.name.replace(' Calculator', '')}</span>
          </div>
        </button>
      `).join('');
    }

    // Rich Search Synonyms, Keywords & Formula Tags per Calculator
    const SEARCH_KEYWORDS = {
      mortgage: ['home loan', 'house', 'emi', 'property tax', 'amortization', 'down payment', 'real estate', 'monthly payment'],
      loan: ['auto loan', 'car loan', 'emi', 'personal loan', 'debt payoff', 'apr', 'interest', 'installment'],
      compound: ['investment', 'wealth', 'savings', 'apy', 'interest', 'future value', 'mutual fund', 'sip'],
      retirement: ['4% rule', 'pension', 'nest egg', 'financial freedom', 'fire', 'senior', 'withdrawal'],
      inflation: ['purchasing power', 'cpi', 'cost of living', 'money value', 'devaluation', 'price rise'],
      salary: ['paycheck', 'hourly to annual', 'wage', 'income tax', 'take home pay', 'gross net', 'biweekly'],
      roi: ['return on investment', 'profit margin', 'cagr', 'markup', 'business revenue', 'gain'],
      bmi: ['body mass index', 'weight loss', 'obesity', 'healthy weight', 'overweight', 'underweight', 'who scale'],
      calorie: ['tdee', 'bmr', 'macros', 'protein', 'carbs', 'fat', 'diet', 'nutrition', 'mifflin st jeor', 'kcal'],
      bodyfat: ['us navy', 'waist', 'neck', 'lean mass', 'adipose', 'fitness percentage'],
      pace: ['running', 'marathon', '5k', '10k', 'jogging', 'speed', 'min/km', 'min/mile', 'cardio'],
      idealweight: ['devine', 'robinson', 'miller', 'target weight', 'body frame', 'height weight'],
      graphing: ['plot', 'desmos', 'function', 'sine wave', 'derivative', 'slope', 'tangent', 'parabola', 'f(x)', 'coordinate'],
      percentage: ['discount', 'percent change', 'increase', 'decrease', 'ratio', 'sale tax', 'tip'],
      fraction: ['numerator', 'denominator', 'gcd', 'simplify', 'mixed number', 'divide', 'multiply'],
      statistics: ['standard deviation', 'mean', 'median', 'variance', 'sample', 'population', 'average', 'data'],
      quadratic: ['roots', 'discriminant', 'ax2+bx+c', 'parabola vertex', 'complex roots', 'algebra', 'equation'],
      triangle: ['pythagoras', 'hypotenuse', 'trigonometry', 'angle', 'area', 'perimeter', 'geometry'],
      unit: ['converter', 'length', 'weight', 'temperature', 'celsius', 'fahrenheit', 'kelvin', 'km to miles', 'kg to lbs', 'speed'],
      ohms: ['electricity', 'voltage', 'current', 'resistance', 'watts', 'power', 'kwh', 'circuit', 'amps', 'physics'],
      age: ['birthday', 'date duration', 'days between', 'weeks', 'hours', 'chronological', 'time span'],
      gpa: ['grade point average', 'college', 'university', 'semester', 'credits', 'cgpa', 'academic'],
      subnet: ['ipv4', 'cidr', 'network mask', 'wildcard', 'hosts', 'ip address', 'it networking'],
      password: ['security', 'entropy', 'random generator', 'cryptography', 'bits', 'brute force', 'key']
    };

    function escapeRegExp(s) {
      return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function highlightText(text, query) {
      if (!query) return text;
      const terms = query.trim().split(/\s+/).filter(Boolean);
      if (terms.length === 0) return text;
      const pattern = new RegExp(`(${terms.map(escapeRegExp).join('|')})`, 'gi');
      return String(text).replace(pattern, '<mark class="bg-amber-200 dark:bg-amber-500/40 text-slate-900 dark:text-white rounded px-0.5">$1</mark>');
    }

    function scoreCalculatorMatch(calc, rawQuery) {
      if (!rawQuery) return 1;
      const q = rawQuery.trim().toLowerCase();
      const terms = q.split(/\s+/).filter(Boolean);
      const nameL = calc.name.toLowerCase();
      const catL = calc.category.toLowerCase();
      const descL = calc.desc.toLowerCase();
      const tags = (SEARCH_KEYWORDS[calc.id] || []).join(' ').toLowerCase();
      const inputsL = calc.inputs.map(i => i.label.toLowerCase()).join(' ');

      let totalScore = 0;
      for (const t of terms) {
        let termScore = 0;
        if (calc.id.toLowerCase() === t) termScore += 120;
        if (nameL.startsWith(t)) termScore += 100;
        else if (nameL.includes(t)) termScore += 75;
        if (tags.includes(t)) termScore += 55;
        if (catL.includes(t)) termScore += 40;
        if (descL.includes(t)) termScore += 30;
        if (inputsL.includes(t)) termScore += 20;

        // Fuzzy subsequence / prefix fallback for slight typos (length >= 3)
        if (termScore === 0 && t.length >= 3) {
          const allWords = (nameL + ' ' + tags + ' ' + descL).split(/[^a-z0-9]+/);
          for (const w of allWords) {
            if (w.startsWith(t.slice(0, 3)) && Math.abs(w.length - t.length) <= 3) {
              termScore += 15;
              break;
            }
          }
        }
        if (termScore === 0) return 0; // All typed tokens must match at least something
        totalScore += termScore;
      }
      return totalScore;
    }

    function getFilteredCalculators(queryStr, categoryFilter = 'all') {
      const q = (queryStr || '').trim();
      let list = CALCULATORS.filter(c => categoryFilter === 'all' || c.category === categoryFilter);
      if (!q) return list;
      return list
        .map(c => ({ calc: c, score: scoreCalculatorMatch(c, q) }))
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .map(item => item.calc);
    }

    function tryEvaluateOmniboxMath(rawQuery) {
      const q = (rawQuery || '').trim();
      if (!q || q.length < 2) return null;
      // Check if it looks like a math expression (contains digits and operators/functions)
      if (!/[0-9]/.test(q)) return null;
      const expr = q
        .replace(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)/gi, '(($1/100)*$2)')
        .replace(/(\d+(?:\.\d+)?)%/g, '($1/100)')
        .replace(/\^/g, '**')
        .replace(/sqrt\(/gi, 'Math.sqrt(')
        .replace(/sin\(/gi, 'Math.sin(')
        .replace(/cos\(/gi, 'Math.cos(')
        .replace(/tan\(/gi, 'Math.tan(')
        .replace(/log\(/gi, 'Math.log10(')
        .replace(/ln\(/gi, 'Math.log(');
      const stripped = expr.replace(/Math\.(sqrt|sin|cos|tan|log10|log)/g, '');
      if (!/^[0-9+\-*/().\s]+$/.test(stripped)) return null;
      // Avoid plain single number unless it had % or operator
      if (/^\d+(\.\d+)?$/.test(q)) return null;
      try {
        const fn = new Function(`"use strict"; return (${expr});`);
        const val = Number(fn());
        if (isFinite(val)) return val;
      } catch (e) {
        return null;
      }
      return null;
    }

    function renderDirectory() {
      const filter = appState.activeCategoryFilter;
      const searchQ = (appState.searchQuery || '').trim();
      const categories = ['Financial', 'Fitness & Health', 'Math', 'Science & Utility'];
      const activeCats = filter === 'all' ? categories : categories.filter(c => c === filter);

      const badge = document.getElementById('activeSearchFilterBadge');
      const queryTextEl = document.getElementById('activeSearchQueryText');
      if (badge && queryTextEl) {
        if (searchQ) {
          queryTextEl.textContent = searchQ;
          badge.classList.remove('hidden');
          badge.classList.add('inline-flex');
        } else {
          badge.classList.add('hidden');
          badge.classList.remove('inline-flex');
        }
      }

      let totalCount = 0;
      const container = document.getElementById('categoryDirectoryContainer');
      const blocks = activeCats.map(cat => {
        const items = getFilteredCalculators(searchQ, cat);
        totalCount += items.length;
        if (items.length === 0) return '';
        return `
          <div class="glass-card rounded-2xl border border-white/60 dark:border-slate-700/70 p-5 shadow-sm">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
              <h3 class="font-extrabold text-base text-slate-900 dark:text-white">${cat} Calculators</h3>
              <span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">${items.length} tools</span>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
              ${items.map(item => {
                const matchedTags = (SEARCH_KEYWORDS[item.id] || []).slice(0, 3).join(' • ');
                return `
                <button type="button" data-open-calc="${item.id}" class="flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-indigo-50/70 dark:hover:bg-slate-800/80 border border-transparent hover:border-indigo-200 dark:hover:border-slate-700 text-left transition group">
                  <span class="text-lg shrink-0 mt-0.5">${item.icon}</span>
                  <div class="min-w-0 flex-1">
                    <div class="text-xs font-bold text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate">${highlightText(item.name, searchQ)}</div>
                    <div class="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">${highlightText(item.desc, searchQ)}</div>
                    ${searchQ ? `<div class="text-[10px] text-indigo-600/80 dark:text-indigo-400/80 mt-0.5 truncate">Tags: ${highlightText(matchedTags, searchQ)}</div>` : ''}
                  </div>
                </button>
              `}).join('')}
            </div>
          </div>
        `;
      }).filter(Boolean);

      if (blocks.length === 0) {
        container.innerHTML = `
          <div class="col-span-full bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3">
            <div class="text-2xl"><div class="flex justify-center text-slate-400"><svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
            <div class="font-bold text-sm">No calculators matched "${searchQ}"</div>
            <p class="text-xs text-slate-500">Try searching by topic (e.g. Mortgage, EMI, BMI, Diet, Fraction, Graph, IP, Ohm) or clear the search filter.</p>
          </div>
        `;
      } else {
        container.innerHTML = blocks.join('');
      }

      document.getElementById('visibleCalcCount').textContent = String(totalCount);
    }

    function renderFavorites() {
      document.getElementById('favCountBadge').textContent = String(appState.favorites.length);
      const grid = document.getElementById('favoritesListGrid');
      if (appState.favorites.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-xs text-amber-800 dark:text-amber-300">No calculators saved yet. Click "Save Tool" on any calculator to bookmark it here.</div>';
        return;
      }
      grid.innerHTML = appState.favorites.map(id => {
        const c = CALCULATORS.find(x => x.id === id);
        if (!c) return '';
        return `
          <div class="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-amber-200/80 dark:border-amber-900/50">
            <button type="button" data-open-calc="${c.id}" class="flex items-center gap-2 text-left text-xs font-bold hover:text-indigo-600 truncate">
              <span>${c.icon}</span>
              <span class="truncate">${c.name}</span>
            </button>
            <button type="button" data-remove-fav="${c.id}" title="Remove bookmark" class="text-xs text-slate-400 hover:text-rose-500 px-1">×</button>
          </div>
        `;
      }).join('');
    }

    function renderHistory() {
      const badge = document.getElementById('historyCountBadge');
      if (badge) badge.textContent = String(appState.history.length);
      const grid = document.getElementById('historyCardsGrid');
      if (!grid) return;
      if (appState.history.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-xs text-cyan-800 dark:text-cyan-300">No calculation history logged yet. Click "+ Log History" on any tool to save a snapshot.</div>';
        return;
      }
      grid.innerHTML = appState.history.map((h, idx) => `
        <div class="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-cyan-200 dark:border-cyan-900/60 shadow-sm space-y-1.5">
          <div class="flex items-center justify-between">
            <button type="button" data-restore-history="${idx}" class="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline">${h.icon} ${h.name}</button>
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-slate-400 font-mono-num">${h.time}</span>
              <button type="button" data-remove-history="${idx}" class="text-xs text-slate-400 hover:text-rose-500">×</button>
            </div>
          </div>
          <div class="text-base font-extrabold font-mono-num">${h.headline}</div>
          <div class="text-[11px] text-slate-500 dark:text-slate-400 truncate">${h.details}</div>
        </div>
      `).join('');
    }

    function logCurrentCalculationToHistory(silent = false) {
      if (!appState.lastResult) return;
      const { calc, vals, res } = appState.lastResult;
      const paramSummary = Object.entries(vals).map(([k, v]) => `${k}: ${v}`).join(' • ');
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      appState.history.unshift({
        calcId: calc.id,
        icon: calc.icon,
        name: calc.name,
        headline: res.summaryLabel,
        details: paramSummary,
        savedVals: { ...vals },
        time: timeStr
      });
      if (appState.history.length > 18) appState.history.pop();
      safeSetStorage('calcverse_history', appState.history);
      renderHistory();
      if (!silent) showToast('Saved snapshot to Calculation History ');
    }

    function renderPins() {
      document.getElementById('pinCountBadge').textContent = String(appState.pins.length);
      const grid = document.getElementById('compareCardsGrid');
      if (appState.pins.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-xs text-emerald-800 dark:text-emerald-300">No scenarios pinned yet. Click "Pin Result to Compare" on any calculator to compare scenarios side-by-side.</div>';
        return;
      }
      grid.innerHTML = appState.pins.map((pin, idx) => `
        <div class="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/60 shadow-sm space-y-1.5">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400">${pin.icon} ${pin.name}</span>
            <button type="button" data-remove-pin="${idx}" class="text-xs text-slate-400 hover:text-rose-500">×</button>
          </div>
          <div class="text-base font-extrabold font-mono-num">${pin.headline}</div>
          <div class="text-[11px] text-slate-500 dark:text-slate-400">${pin.details}</div>
        </div>
      `).join('');
    }

    // =========================================================================
    // 6. EVENT DELEGATION & CONTROLS
    // =========================================================================
    document.body.addEventListener('click', e => {
      const openBtn = e.target.closest('[data-open-calc]');
      if (openBtn) {
        selectCalculator(openBtn.getAttribute('data-open-calc'), true);
        document.getElementById('searchDropdown').classList.add('hidden');
        return;
      }

      const quickBtn = e.target.closest('[data-quick-calc]');
      if (quickBtn) {
        selectCalculator(quickBtn.getAttribute('data-quick-calc'), true);
        return;
      }

      const remFav = e.target.closest('[data-remove-fav]');
      if (remFav) {
        const id = remFav.getAttribute('data-remove-fav');
        appState.favorites = appState.favorites.filter(x => x !== id);
        safeSetStorage('calcverse_favorites', appState.favorites);
        renderFavorites();
        renderActiveWorkspace();
        return;
      }

      const remPin = e.target.closest('[data-remove-pin]');
      if (remPin) {
        const idx = Number(remPin.getAttribute('data-remove-pin'));
        appState.pins.splice(idx, 1);
        safeSetStorage('calcverse_pins', appState.pins);
        renderPins();
        return;
      }

      const remHist = e.target.closest('[data-remove-history]');
      if (remHist) {
        const idx = Number(remHist.getAttribute('data-remove-history'));
        appState.history.splice(idx, 1);
        safeSetStorage('calcverse_history', appState.history);
        renderHistory();
        return;
      }

      const restHist = e.target.closest('[data-restore-history]');
      if (restHist) {
        const idx = Number(restHist.getAttribute('data-restore-history'));
        const item = appState.history[idx];
        if (item && item.calcId) {
          appState.activeCalcId = item.calcId;
          appState.inputValues[item.calcId] = { ...item.savedVals };
          renderActiveWorkspace();
          document.getElementById('activeCalculatorWorkspace').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          showToast(`Restored ${item.name} snapshot`);
        }
      }
    });

    // Category filter pills (Touch + Mouse Drag-to-Swipe + Wheel + Dynamic ‹/› Arrows)
    const categoryFilterTrack = document.getElementById('categoryFilterTrack');
    const filterSwipeLeftBtn = document.getElementById('filterSwipeLeftBtn');
    const filterSwipeRightBtn = document.getElementById('filterSwipeRightBtn');

    let filterIsDragging = false;
    let filterDragMoved = false;
    let filterStartX = 0;
    let filterStartScrollLeft = 0;

    function updateFilterSwipeArrows() {
      if (!categoryFilterTrack || !filterSwipeLeftBtn || !filterSwipeRightBtn) return;
      const maxScroll = categoryFilterTrack.scrollWidth - categoryFilterTrack.clientWidth;
      const showLeft = categoryFilterTrack.scrollLeft > 4;
      const showRight = maxScroll - categoryFilterTrack.scrollLeft > 4;
      filterSwipeLeftBtn.classList.toggle('hidden', !showLeft);
      filterSwipeLeftBtn.classList.toggle('flex', showLeft);
      filterSwipeRightBtn.classList.toggle('hidden', !showRight);
      filterSwipeRightBtn.classList.toggle('flex', showRight);
    }

    if (categoryFilterTrack) {
      categoryFilterTrack.addEventListener('mousedown', e => {
        filterIsDragging = true;
        filterDragMoved = false;
        filterStartX = e.pageX;
        filterStartScrollLeft = categoryFilterTrack.scrollLeft;
      });
      window.addEventListener('mousemove', e => {
        if (!filterIsDragging) return;
        const dx = e.pageX - filterStartX;
        if (Math.abs(dx) > 5) filterDragMoved = true;
        categoryFilterTrack.scrollLeft = filterStartScrollLeft - dx;
      });
      window.addEventListener('mouseup', () => {
        filterIsDragging = false;
        setTimeout(() => { filterDragMoved = false; }, 40);
      });
      categoryFilterTrack.addEventListener('wheel', e => {
        if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
          categoryFilterTrack.scrollLeft += e.deltaY;
          e.preventDefault();
        }
      }, { passive: false });
      categoryFilterTrack.addEventListener('scroll', updateFilterSwipeArrows);
      window.addEventListener('resize', updateFilterSwipeArrows);
      setTimeout(updateFilterSwipeArrows, 120);
    }

    document.querySelectorAll('[data-cat-filter]').forEach(btn => {
      btn.addEventListener('click', e => {
        if (filterDragMoved) {
          e.preventDefault();
          return;
        }
        appState.activeCategoryFilter = btn.getAttribute('data-cat-filter');
        document.querySelectorAll('[data-cat-filter]').forEach(b => {
          b.className = 'cat-pill shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 whitespace-nowrap transition';
        });
        btn.className = 'cat-pill shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 text-white shadow-sm whitespace-nowrap transition';
        btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
        setTimeout(updateFilterSwipeArrows, 250);
        renderDirectory();
      });
    });

    if (filterSwipeLeftBtn && categoryFilterTrack) {
      filterSwipeLeftBtn.addEventListener('click', () => {
        categoryFilterTrack.scrollBy({ left: -180, behavior: 'smooth' });
      });
    }
    if (filterSwipeRightBtn && categoryFilterTrack) {
      filterSwipeRightBtn.addEventListener('click', () => {
        categoryFilterTrack.scrollBy({ left: 180, behavior: 'smooth' });
      });
    }

    // Reset current calculator inputs
    document.getElementById('resetCalcInputsBtn').addEventListener('click', () => {
      const calc = getActiveCalc();
      initCalcDefaults(calc, true);
      renderActiveWorkspace();
      showToast(`Reset ${calc.name} to default values`);
    });

    // Save/Unsave current calculator
    document.getElementById('favCurrentCalcBtn').addEventListener('click', () => {
      const id = appState.activeCalcId;
      if (appState.favorites.includes(id)) {
        appState.favorites = appState.favorites.filter(x => x !== id);
        showToast('Removed from Saved Calculators');
      } else {
        appState.favorites.push(id);
        showToast('Added to Saved Calculators ');
      }
      safeSetStorage('calcverse_favorites', appState.favorites);
      renderFavorites();
      renderActiveWorkspace();
    });

    // Pin current result to compare drawer
    document.getElementById('pinCurrentResultBtn').addEventListener('click', () => {
      if (!appState.lastResult) return;
      const { calc, vals, res } = appState.lastResult;
      const paramSummary = Object.entries(vals).map(([k, v]) => `${k}: ${v}`).join(' • ');
      appState.pins.unshift({
        icon: calc.icon,
        name: calc.name,
        headline: res.summaryLabel,
        details: paramSummary
      });
      if (appState.pins.length > 9) appState.pins.pop();
      safeSetStorage('calcverse_pins', appState.pins);
      renderPins();
      document.getElementById('compareDrawerSection').classList.remove('hidden');
      showToast('Pinned scenario to comparison board ');
    });

    // =========================================================================
    // NOSTALGIC PAPER RECEIPT & VINTAGE RECIPE CARD GENERATOR
    // =========================================================================
    const nostalgicState = {
      paperStyle: 'roll', // 'roll' | 'recipe'
      sourceMode: 'calculator' // 'calculator' | 'tape'
    };

    function buildNostalgicSlipData() {
      const nowStr = 'NOV 18, 2026 • 02:49 AM';
      const serialNo = 'CV-' + String(197800 + Math.floor((appState.activeCalcId.length * 137) % 899));

      if (nostalgicState.sourceMode === 'tape') {
        const tapeEntries = sciState.tape.length > 0
          ? sciState.tape.map((t, i) => ({ label: `ITEM #${String(i + 1).padStart(2, '0')}: ${t.expr}`, val: fmtNum(t.result, 6) }))
          : [{ label: `DISPLAY: ${sciScreenInput.value}`, val: sciScreenInput.value }];
        return {
          headerTitle: 'CALCVERSE MECHANICAL TAPE',
          subHeader: 'MODEL CV-80 • SCIENTIFIC REGISTER',
          serialNo,
          dateStr: nowStr,
          sectionAHeader: 'TAPE ENTRIES (CHRONOLOGICAL)',
          rows: tapeEntries,
          sectionBHeader: 'MEMORY & ACCUMULATOR',
          steps: [
            `MEMORY REGISTER (M) = ${fmtNum(sciState.memory, 4)}`,
            `LAST ANSWER (ANS)   = ${fmtNum(sciState.ans, 6)}`,
            `TRIG ANGLE MODE     = ${sciState.degMode ? 'DEGREES (DEG)' : 'RADIANS (RAD)'}`
          ],
          grandLabel: 'FINAL DISPLAY TOTAL',
          grandValue: String(sciScreenInput.value),
          stampText: 'VERIFIED BY CALCVERSE • NOSTALGIA EDITION'
        };
      }

      const { calc, vals, res } = appState.lastResult || {
        calc: getActiveCalc(),
        vals: appState.inputValues[appState.activeCalcId] || {},
        res: getActiveCalc().compute(appState.inputValues[appState.activeCalcId] || {})
      };

      const rows = calc.inputs.map(inp => {
        let displayVal = vals[inp.key];
        if (inp.type === 'select' && inp.options) {
          const found = inp.options.find(o => String(o.v) === String(displayVal));
          if (found) displayVal = found.l;
        }
        return { label: inp.label.toUpperCase(), val: String(displayVal) };
      });

      const kpiRows = res.kpis.map(k => ({
        label: k.label.toUpperCase(),
        val: `${k.value} (${k.sub})`
      }));

      return {
        headerTitle: nostalgicState.paperStyle === 'recipe'
          ? `RECIPE FOR: ${calc.name.toUpperCase()}`
          : `CALCVERSE VINTAGE SLIP • ${calc.category.toUpperCase()}`,
        subHeader: calc.name.toUpperCase(),
        serialNo,
        dateStr: nowStr,
        sectionAHeader: nostalgicState.paperStyle === 'recipe'
          ? 'INGREDIENTS (INPUT PARAMETERS)'
          : 'INPUT PARAMETERS',
        rows,
        kpiRows,
        sectionBHeader: nostalgicState.paperStyle === 'recipe'
          ? 'METHOD & STEP-BY-STEP DIRECTIONS'
          : 'FORMULA & SOLUTION WORKINGS',
        steps: res.formulaSteps,
        grandLabel: nostalgicState.paperStyle === 'recipe' ? 'YIELD / FINAL RESULT' : 'TOTAL COMPUTED RESULT',
        grandValue: res.summaryLabel,
        stampText: 'INSPECTED & CERTIFIED • EST. 1978'
      };
    }

    function renderNostalgicModalPreview() {
      const data = buildNostalgicSlipData();
      const surface = document.getElementById('nostalgicPaperSurface');
      const zTop = document.getElementById('zigzagTopBar');
      const zBot = document.getElementById('zigzagBottomBar');

      if (nostalgicState.paperStyle === 'recipe') {
        surface.className = 'nostalgic-recipe-card p-6 pl-12 rounded-lg text-xs space-y-3 border border-amber-900/30';
        zTop.classList.add('hidden');
        zBot.classList.add('hidden');
      } else {
        surface.className = 'nostalgic-paper-roll p-5 text-xs space-y-3';
        zTop.classList.remove('hidden');
        zBot.classList.remove('hidden');
      }

      const rowsHtml = data.rows.map(r => `
        <div class="flex justify-between gap-2 border-b border-dotted border-amber-900/30 pb-0.5">
          <span class="opacity-80">${r.label}</span>
          <span class="font-bold text-right">${r.val}</span>
        </div>
      `).join('');

      const kpiHtml = (data.kpiRows || []).map(k => `
        <div class="flex justify-between gap-2 text-[11px]">
          <span class="opacity-75">${k.label}:</span>
          <span class="font-semibold text-right">${k.val}</span>
        </div>
      `).join('');

      const stepsHtml = data.steps.map((s, idx) => `
        <div class="leading-relaxed">${idx + 1}. ${s}</div>
      `).join('');

      surface.innerHTML = `
        <div class="text-center border-b-2 border-dashed border-amber-950/40 pb-2.5 space-y-0.5">
          <div class="font-extrabold tracking-widest text-sm">${data.headerTitle}</div>
          <div class="text-[11px] opacity-75">${data.subHeader}</div>
          <div class="text-[10px] opacity-60 flex justify-between pt-1">
            <span>NO. ${data.serialNo}</span>
            <span>${data.dateStr}</span>
          </div>
        </div>

        <div class="space-y-1">
          <div class="font-bold text-[11px] tracking-wider uppercase text-amber-950 underline decoration-dotted">${data.sectionAHeader}</div>
          ${rowsHtml}
        </div>

        ${kpiHtml ? `
        <div class="space-y-1 pt-1 border-t border-dashed border-amber-950/30">
          <div class="font-bold text-[11px] tracking-wider uppercase text-amber-950">COMPUTED BREAKDOWN</div>
          ${kpiHtml}
        </div>` : ''}

        <div class="space-y-1 pt-1 border-t border-dashed border-amber-950/30">
          <div class="font-bold text-[11px] tracking-wider uppercase text-amber-950">${data.sectionBHeader}</div>
          <div class="text-[11px] space-y-1 opacity-90">${stepsHtml}</div>
        </div>

        <div class="pt-2 border-t-2 border-double border-amber-950/60 flex items-center justify-between">
          <span class="font-extrabold text-xs tracking-wider">${data.grandLabel}:</span>
          <span class="font-extrabold text-base px-2 py-0.5 bg-amber-900/10 border border-amber-900/40 rounded">${data.grandValue}</span>
        </div>

        <div class="pt-2 text-center">
          <span class="inline-block px-2.5 py-0.5 border-2 border-rose-800/60 text-rose-900/80 font-extrabold text-[10px] tracking-widest uppercase -rotate-2 rounded">
            ${data.stampText}
          </span>
          <div class="text-[10px] opacity-55 mt-1.5">*** KEEP THIS SLIP FOR YOUR RECORDS ***</div>
        </div>
      `;
    }

    function openNostalgicModal(sourceMode) {
      nostalgicState.sourceMode = sourceMode;
      renderNostalgicModalPreview();
      document.getElementById('nostalgicPaperModal').classList.remove('hidden');
    }

    function drawWrappedCanvasText(ctx, text, x, y, maxWidth, lineHeight) {
      const words = String(text).split(' ');
      let line = '';
      let curY = y;
      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && n > 0) {
          ctx.fillText(line.trim(), x, curY);
          line = words[n] + ' ';
          curY += lineHeight;
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line.trim(), x, curY);
      return curY + lineHeight;
    }

    function downloadNostalgicPaperPng() {
      const data = buildNostalgicSlipData();
      const canvas = document.getElementById('nostalgicPaperCanvas');
      const ctx = canvas.getContext('2d');
      const W = 760;
      const H = 1020;
      canvas.width = W;
      canvas.height = H;

      // 1. Aged dark desk backdrop
      ctx.fillStyle = '#1e1b18';
      ctx.fillRect(0, 0, W, H);

      const padX = 55;
      const padY = 45;
      const cardW = W - padX * 2;
      const cardH = H - padY * 2;

      // 2. Vintage Paper Base with Warm Sepia Gradient
      const grad = ctx.createLinearGradient(padX, padY, padX + cardW, padY + cardH);
      if (nostalgicState.paperStyle === 'recipe') {
        grad.addColorStop(0, '#fcf5e5');
        grad.addColorStop(0.5, '#f7ecd5');
        grad.addColorStop(1, '#efe0c2');
      } else {
        grad.addColorStop(0, '#f7efe0');
        grad.addColorStop(0.5, '#f2e6cf');
        grad.addColorStop(1, '#e8d7b9');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(padX, padY, cardW, cardH);

      // 3. Subtle Vintage Paper Grain & Coffee Ring Stain
      ctx.fillStyle = 'rgba(139, 98, 52, 0.05)';
      for (let i = 0; i < 650; i++) {
        const gx = padX + ((i * 97) % cardW);
        const gy = padY + ((i * 151) % cardH);
        ctx.fillRect(gx, gy, 2, 2);
      }
      ctx.strokeStyle = 'rgba(155, 108, 60, 0.09)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(padX + cardW - 110, padY + cardH - 130, 58, 0, Math.PI * 2);
      ctx.stroke();

      // 4. Serrated Tear Teeth (for Thermal Roll) or Ruled Index Lines (for Recipe Card)
      if (nostalgicState.paperStyle === 'roll') {
        ctx.fillStyle = '#1e1b18';
        const toothW = 16;
        for (let x = padX; x < padX + cardW; x += toothW) {
          // Top zig-zag
          ctx.beginPath();
          ctx.moveTo(x, padY);
          ctx.lineTo(x + toothW / 2, padY + 10);
          ctx.lineTo(x + toothW, padY);
          ctx.closePath();
          ctx.fill();
          // Bottom zig-zag
          ctx.beginPath();
          ctx.moveTo(x, padY + cardH);
          ctx.lineTo(x + toothW / 2, padY + cardH - 10);
          ctx.lineTo(x + toothW, padY + cardH);
          ctx.closePath();
          ctx.fill();
        }
      } else {
        // Recipe card red vertical margin line + horizontal blue/sepia ruled lines
        ctx.strokeStyle = 'rgba(205, 75, 75, 0.42)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(padX + 48, padY);
        ctx.lineTo(padX + 48, padY + cardH);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(160, 130, 95, 0.22)';
        ctx.lineWidth = 1;
        for (let ry = padY + 95; ry < padY + cardH - 30; ry += 32) {
          ctx.beginPath();
          ctx.moveTo(padX, ry);
          ctx.lineTo(padX + cardW, ry);
          ctx.stroke();
        }
      }

      const leftM = nostalgicState.paperStyle === 'recipe' ? padX + 68 : padX + 36;
      const rightM = padX + cardW - 36;
      const contentW = rightM - leftM;
      let curY = padY + 52;

      // 5. Header Typography
      ctx.fillStyle = '#2b2017';
      ctx.font = 'bold 21px "JetBrains Mono", Courier, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(data.headerTitle, padX + cardW / 2, curY);
      curY += 26;

      ctx.font = '14px "JetBrains Mono", Courier, monospace';
      ctx.fillStyle = '#5c4938';
      ctx.fillText(data.subHeader, padX + cardW / 2, curY);
      curY += 24;

      ctx.font = '12px "JetBrains Mono", Courier, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`REF: ${data.serialNo}`, leftM, curY);
      ctx.textAlign = 'right';
      ctx.fillText(data.dateStr, rightM, curY);
      curY += 16;

      // Dashed divider
      ctx.strokeStyle = '#6e5641';
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(leftM, curY);
      ctx.lineTo(rightM, curY);
      ctx.stroke();
      ctx.setLineDash([]);
      curY += 28;

      // 6. Section A: Parameters / Ingredients
      ctx.textAlign = 'left';
      ctx.fillStyle = '#3d2b1f';
      ctx.font = 'bold 14px "JetBrains Mono", Courier, monospace';
      ctx.fillText(data.sectionAHeader, leftM, curY);
      curY += 24;

      ctx.font = '13px "JetBrains Mono", Courier, monospace';
      data.rows.forEach(r => {
        ctx.fillStyle = '#4a3a2c';
        ctx.textAlign = 'left';
        ctx.fillText(r.label.slice(0, 34), leftM, curY);
        ctx.fillStyle = '#1f1610';
        ctx.font = 'bold 13px "JetBrains Mono", Courier, monospace';
        ctx.textAlign = 'right';
        ctx.fillText(String(r.val).slice(0, 28), rightM, curY);
        ctx.font = '13px "JetBrains Mono", Courier, monospace';
        curY += 24;
      });

      // KPI Breakdown rows if present
      if (data.kpiRows && data.kpiRows.length > 0) {
        curY += 8;
        ctx.strokeStyle = '#8c7258';
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(leftM, curY);
        ctx.lineTo(rightM, curY);
        ctx.stroke();
        ctx.setLineDash([]);
        curY += 24;

        ctx.textAlign = 'left';
        ctx.fillStyle = '#3d2b1f';
        ctx.font = 'bold 14px "JetBrains Mono", Courier, monospace';
        ctx.fillText('COMPUTED SUMMARY BREAKDOWN', leftM, curY);
        curY += 24;

        data.kpiRows.forEach(k => {
          ctx.font = '13px "JetBrains Mono", Courier, monospace';
          ctx.fillStyle = '#4a3a2c';
          ctx.textAlign = 'left';
          ctx.fillText(k.label.slice(0, 28), leftM, curY);
          ctx.fillStyle = '#1f1610';
          ctx.font = 'bold 13px "JetBrains Mono", Courier, monospace';
          ctx.textAlign = 'right';
          ctx.fillText(k.val.slice(0, 34), rightM, curY);
          curY += 24;
        });
      }

      // 7. Section B: Formula & Steps
      curY += 8;
      ctx.strokeStyle = '#8c7258';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(leftM, curY);
      ctx.lineTo(rightM, curY);
      ctx.stroke();
      ctx.setLineDash([]);
      curY += 26;

      ctx.textAlign = 'left';
      ctx.fillStyle = '#3d2b1f';
      ctx.font = 'bold 14px "JetBrains Mono", Courier, monospace';
      ctx.fillText(data.sectionBHeader, leftM, curY);
      curY += 24;

      ctx.font = '12.5px "JetBrains Mono", Courier, monospace';
      ctx.fillStyle = '#2f241b';
      data.steps.forEach((stepStr, idx) => {
        curY = drawWrappedCanvasText(ctx, `${idx + 1}. ${stepStr}`, leftM, curY, contentW, 20);
        curY += 4;
      });

      // 8. Grand Total Box near bottom
      const boxY = Math.max(curY + 16, padY + cardH - 165);
      ctx.strokeStyle = '#2b2017';
      ctx.lineWidth = 2;
      ctx.strokeRect(leftM, boxY, contentW, 54);
      ctx.fillStyle = 'rgba(139, 98, 52, 0.10)';
      ctx.fillRect(leftM, boxY, contentW, 54);

      ctx.fillStyle = '#2b2017';
      ctx.font = 'bold 15px "JetBrains Mono", Courier, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(data.grandLabel, leftM + 16, boxY + 33);

      ctx.font = 'bold 20px "JetBrains Mono", Courier, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(data.grandValue, rightM - 16, boxY + 34);

      // 9. Vintage Rubber Ink Stamp
      ctx.save();
      ctx.translate(padX + cardW / 2, boxY + 92);
      ctx.rotate(-0.035);
      ctx.strokeStyle = 'rgba(165, 42, 42, 0.72)';
      ctx.lineWidth = 2;
      ctx.strokeRect(-185, -16, 370, 28);
      ctx.fillStyle = 'rgba(165, 42, 42, 0.78)';
      ctx.font = 'bold 12px "JetBrains Mono", Courier, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(data.stampText, 0, 3);
      ctx.restore();

      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      const slug = nostalgicState.sourceMode === 'tape' ? 'scientific_tape' : appState.activeCalcId;
      a.download = `calcverse_nostalgic_${ nostalSlug(slug) }_${nostalgicState.paperStyle}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast('Downloaded nostalgic vintage paper keepsake (.PNG)! ');
    }

    function nostalSlug(s) {
      return String(s).replace(/[^a-z0-9_-]/gi, '_').toLowerCase();
    }

    function downloadNostalgicStandaloneHtml() {
      const data = buildNostalgicSlipData();
      const surfaceHtml = document.getElementById('nostalgicPaperSurface').innerHTML;
      const standalone = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>${data.headerTitle}</title>
<style>
  body { background: #e5dccb; display: flex; justify-content: center; padding: 40px 16px; font-family: 'Courier New', monospace; color: #2b2017; }
  .slip { background: #f6eedc; max-width: 420px; width: 100%; padding: 28px; border: 1px solid #c8b496; box-shadow: 0 10px 25px rgba(0,0,0,0.18); }
  .flex { display: flex; justify-content: space-between; margin: 6px 0; }
  .border-b { border-bottom: 1px dotted #8c7258; padding-bottom: 4px; }
  .font-bold, .font-extrabold { font-weight: bold; }
  .text-center { text-align: center; }
  @media print { body { background: none; padding: 0; } .slip { box-shadow: none; } }
</style>
</head>
<body>
  <div class="slip">${surfaceHtml}</div>
</body>
</html>`;
      const blob = new Blob([standalone], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `calcverse_vintage_slip_${appState.activeCalcId}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('Downloaded printable vintage paper slip (.HTML)! ');
    }

    document.getElementById('openNostalgicSlipBtn').addEventListener('click', () => openNostalgicModal('calculator'));
    document.getElementById('downloadTapeReceiptBtn').addEventListener('click', () => openNostalgicModal('tape'));
    document.getElementById('closeNostalgicModalBtn').addEventListener('click', () => {
      document.getElementById('nostalgicPaperModal').classList.add('hidden');
    });
    document.getElementById('styleThermalRollBtn').addEventListener('click', () => {
      nostalgicState.paperStyle = 'roll';
      document.getElementById('styleThermalRollBtn').className = 'px-3 py-1.5 rounded-md font-semibold bg-amber-600 text-white transition';
      document.getElementById('styleRecipeCardBtn').className = 'px-3 py-1.5 rounded-md font-semibold text-slate-300 hover:text-white transition';
      renderNostalgicModalPreview();
    });
    document.getElementById('styleRecipeCardBtn').addEventListener('click', () => {
      nostalgicState.paperStyle = 'recipe';
      document.getElementById('styleRecipeCardBtn').className = 'px-3 py-1.5 rounded-md font-semibold bg-amber-600 text-white transition';
      document.getElementById('styleThermalRollBtn').className = 'px-3 py-1.5 rounded-md font-semibold text-slate-300 hover:text-white transition';
      renderNostalgicModalPreview();
    });
    document.getElementById('downloadNostalgicPngBtn').addEventListener('click', downloadNostalgicPaperPng);
    document.getElementById('downloadNostalgicHtmlBtn').addEventListener('click', downloadNostalgicStandaloneHtml);
    document.getElementById('copyNostalgicTextBtn').addEventListener('click', () => {
      const data = buildNostalgicSlipData();
      const lines = [
        `========================================`,
        `  ${data.headerTitle}`,
        `  ${data.subHeader}`,
        `  REF: ${data.serialNo} | ${data.dateStr}`,
        `========================================`,
        `[${data.sectionAHeader}]`,
        ...data.rows.map(r => `  ${r.label}: ${r.val}`),
        `----------------------------------------`,
        `[${data.sectionBHeader}]`,
        ...data.steps.map((s, i) => `  ${i + 1}. ${s}`),
        `========================================`,
        `  ${data.grandLabel}: ${data.grandValue}`,
        `  ${data.stampText}`,
        `========================================`
      ];
      copyTextToClipboard(lines.join('\n'), 'Copied nostalgic receipt text!');
    });

    // Log to History button
    document.getElementById('logToHistoryBtn').addEventListener('click', () => {
      logCurrentCalculationToHistory(false);
      document.getElementById('historyDrawerSection').classList.remove('hidden');
    });

    document.getElementById('toggleHistoryDrawerBtn').addEventListener('click', () => {
      renderHistory();
      const sec = document.getElementById('historyDrawerSection');
      const willOpen = sec.classList.contains('hidden');
      sec.classList.toggle('hidden');
      if (willOpen) sec.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
    document.getElementById('closeHistorySectionBtn').addEventListener('click', () => {
      document.getElementById('historyDrawerSection').classList.add('hidden');
    });
    document.getElementById('clearHistoryBtn').addEventListener('click', () => {
      appState.history = [];
      safeSetStorage('calcverse_history', []);
      renderHistory();
      showToast('Cleared Calculation History');
    });

    // Export Excel (.CSV with UTF-8 BOM for Microsoft Excel & Google Sheets)
    document.getElementById('exportCurrentExcelBtn').addEventListener('click', () => {
      if (!appState.lastResult) return;
      const { calc, vals, res } = appState.lastResult;
      const q = s => `"${String(s).replace(/"/g, '""')}"`;
      const rows = [
        ['CalcVerse Pro — Structured Spreadsheet Export'],
        ['Calculator Name', calc.name],
        ['Category', calc.category],
        ['Primary Result', res.summaryLabel],
        [],
        ['Section', 'Parameter / Metric', 'Value', 'Notes / Details'],
        ...calc.inputs.map(inp => ['Input Parameter', inp.label, vals[inp.key], inp.type]),
        [],
        ...res.kpis.map(k => ['Computed Output', k.label, k.value, k.sub]),
        [],
        ...res.formulaSteps.map((s, idx) => ['Formula Step ' + (idx + 1), s, '', 'Verified'])
      ];
      const csvContent = '\uFEFF' + rows.map(r => r.map(q).join(',')).join('\r\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `calcverse_${calc.id}_spreadsheet.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast(`Exported ${calc.name} Excel (.CSV) spreadsheet! `);
    });

    // Export PDF Report (using jsPDF if loaded, with HTML print fallback)
    document.getElementById('exportCurrentPdfBtn').addEventListener('click', () => {
      if (!appState.lastResult) return;
      const { calc, vals, res } = appState.lastResult;
      if (window.jspdf && window.jspdf.jsPDF) {
        const doc = new window.jspdf.jsPDF({ unit: 'pt', format: 'a4' });
        let y = 50;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(18);
        doc.setTextColor(30, 41, 59);
        doc.text(`CalcVerse Pro — ${calc.name}`, 45, y);
        y += 20;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(100, 116, 139);
        doc.text(`Category: ${calc.category} | Verified Formula & Calculation Report`, 45, y);
        y += 24;

        doc.setDrawColor(203, 213, 225);
        doc.line(45, y, 550, y);
        y += 22;

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.setTextColor(79, 70, 229);
        doc.text(`Headline Result: ${res.summaryLabel}`, 45, y);
        y += 26;

        doc.setFontSize(11);
        doc.setTextColor(30, 41, 59);
        doc.text('1. Input Parameters', 45, y);
        y += 18;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        calc.inputs.forEach(inp => {
          doc.text(`• ${inp.label}: ${vals[inp.key]}`, 55, y);
          y += 16;
        });

        y += 12;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.text('2. Computed Outputs & KPIs', 45, y);
        y += 18;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        res.kpis.forEach(k => {
          doc.text(`• ${k.label}: ${k.value} (${k.sub})`, 55, y);
          y += 16;
        });

        y += 12;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.text('3. Verified Formula & Step-by-Step Solution', 45, y);
        y += 18;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9.5);
        res.formulaSteps.forEach((s, i) => {
          const split = doc.splitTextToSize(`${i + 1}. ${s}`, 490);
          doc.text(split, 55, y);
          y += split.length * 14 + 4;
        });

        doc.save(`calcverse_${calc.id}_report.pdf`);
        showToast(`Downloaded ${calc.name} PDF Report! `);
      } else {
        downloadNostalgicStandaloneHtml();
      }
    });

    // Export Modern High-DPI PNG Summary Card
    document.getElementById('exportCurrentPngBtn').addEventListener('click', () => {
      if (!appState.lastResult) return;
      const { calc, vals, res } = appState.lastResult;
      const canvas = document.getElementById('nostalgicPaperCanvas');
      const ctx = canvas.getContext('2d');
      const W = 800, H = 560;
      canvas.width = W;
      canvas.height = H;

      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(1, '#1e1b4b');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      ctx.strokeStyle = 'rgba(99, 102, 241, 0.45)';
      ctx.lineWidth = 2;
      ctx.strokeRect(24, 24, W - 48, H - 48);

      ctx.fillStyle = '#818cf8';
      ctx.font = 'bold 13px Inter, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`CALCVERSE PRO • ${calc.category.toUpperCase()}`, 48, 64);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 26px Inter, sans-serif';
      ctx.fillText(calc.name, 48, 98);

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 22px "JetBrains Mono", monospace';
      ctx.textAlign = 'right';
      ctx.fillText(res.summaryLabel, W - 48, 96);

      ctx.textAlign = 'left';
      let y = 145;
      res.kpis.forEach((k, idx) => {
        const cardX = 48 + idx * 238;
        ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
        ctx.fillRect(cardX, y, 224, 92);
        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 11px Inter, sans-serif';
        ctx.fillText(k.label.toUpperCase().slice(0, 26), cardX + 14, y + 26);
        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 18px "JetBrains Mono", monospace';
        ctx.fillText(String(k.value).slice(0, 18), cardX + 14, y + 54);
        ctx.fillStyle = '#38bdf8';
        ctx.font = '11px Inter, sans-serif';
        ctx.fillText(String(k.sub).slice(0, 28), cardX + 14, y + 76);
      });

      y = 275;
      ctx.fillStyle = '#cbd5e1';
      ctx.font = 'bold 13px Inter, sans-serif';
      ctx.fillText('INPUT PARAMETERS & VERIFIED FORMULA STEPS', 48, y);
      y += 24;

      const paramStr = calc.inputs.map(i => `${i.label}: ${vals[i.key]}`).join('  |  ');
      ctx.fillStyle = '#94a3b8';
      ctx.font = '12px "JetBrains Mono", monospace';
      ctx.fillText(paramStr.slice(0, 92), 48, y);
      y += 28;

      ctx.fillStyle = '#e2e8f0';
      res.formulaSteps.forEach((s, i) => {
        ctx.fillText(`${i + 1}. ${s.slice(0, 90)}`, 48, y);
        y += 24;
      });

      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `calcverse_${calc.id}_card.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast(`Downloaded ${calc.name} PNG Summary Card! `);
    });

    // Export CSV / text report
    document.getElementById('exportCurrentCsvBtn').addEventListener('click', () => {
      if (!appState.lastResult) return;
      const { calc, vals, res } = appState.lastResult;
      const lines = [
        `CalcVerse Calculation Report - ${calc.name}`,
        `Category: ${calc.category}`,
        `Headline Result: ${res.summaryLabel}`,
        '',
        '--- Input Parameters ---',
        ...Object.entries(vals).map(([k, v]) => `${k},${v}`),
        '',
        '--- Key Outputs ---',
        ...res.kpis.map(k => `${k.label},"${k.value}" (${k.sub})`),
        '',
        '--- Formula & Solution Steps ---',
        ...res.formulaSteps
      ];
      const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${calc.id}_calculation_report.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast(`Exported ${calc.name} report`);
    });

    // Copy formula steps
    document.getElementById('copyFormulaStepsBtn').addEventListener('click', () => {
      if (!appState.lastResult) return;
      const text = appState.lastResult.res.formulaSteps.join('\n');
      copyTextToClipboard(text, 'Formula steps copied to clipboard!');
    });

    // Toggle Favorites, Pinboard & History drawers (with smooth scroll into view)
    document.getElementById('toggleFavoritesBtn').addEventListener('click', () => {
      renderFavorites();
      const sec = document.getElementById('favoritesSection');
      const willOpen = sec.classList.contains('hidden');
      sec.classList.toggle('hidden');
      if (willOpen) sec.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
    document.getElementById('closeFavoritesSectionBtn').addEventListener('click', () => {
      document.getElementById('favoritesSection').classList.add('hidden');
    });
    document.getElementById('toggleCompareDrawerBtn').addEventListener('click', () => {
      renderPins();
      const sec = document.getElementById('compareDrawerSection');
      const willOpen = sec.classList.contains('hidden');
      sec.classList.toggle('hidden');
      if (willOpen) sec.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
    document.getElementById('closeCompareSectionBtn').addEventListener('click', () => {
      document.getElementById('compareDrawerSection').classList.add('hidden');
    });
    document.getElementById('clearPinsBtn').addEventListener('click', () => {
      appState.pins = [];
      safeSetStorage('calcverse_pins', []);
      renderPins();
      showToast('Cleared comparison board');
    });

    // Brand Home button scrolls to top
    document.getElementById('brandHomeBtn').addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // =========================================================================
    // SMART GLOBAL SEARCH & OMNIBOX ENGINE (SYNONYMS + INSTANT MATH + KEYBOARD)
    // =========================================================================
    const searchInput = document.getElementById('globalSearchInput');
    const searchDropdown = document.getElementById('searchDropdown');
    const clearSearchInputBtn = document.getElementById('clearSearchInputBtn');
    const resetDirectorySearchBtn = document.getElementById('resetDirectorySearchBtn');

    appState.searchQuery = '';
    appState.recentSearches = safeGetStorage('calcverse_recent_searches', ['mortgage', 'bmi', 'compound', 'subnet']);
    appState.searchActiveIndex = -1;
    appState.currentSearchMatches = [];

    function saveRecentSearchTerm(term) {
      const clean = (term || '').trim();
      if (!clean || clean.length < 2) return;
      appState.recentSearches = [clean, ...appState.recentSearches.filter(x => x.toLowerCase() !== clean.toLowerCase())].slice(0, 6);
      safeSetStorage('calcverse_recent_searches', appState.recentSearches);
    }

    function renderSearchDropdown() {
      const rawQ = searchInput.value;
      const q = rawQ.trim();
      clearSearchInputBtn.classList.toggle('hidden', q.length === 0);

      // Update live directory filtering simultaneously
      appState.searchQuery = q;
      renderDirectory();

      // Case 1: Input is focused but empty -> Show Recent Searches & Trending Quick Tags
      if (!q) {
        appState.currentSearchMatches = CALCULATORS.filter(c => c.popular);
        appState.searchActiveIndex = -1;
        const trendingTags = [
          { label: 'Mortgage EMI', q: 'mortgage' },
          { label: 'BMI & Weight', q: 'bmi' },
          { label: 'Diet & Macros', q: 'macros' },
          { label: 'Function Plotter', q: 'graph' },
          { label: 'km to miles', q: 'unit' },
          { label: 'IPv4 CIDR', q: 'cidr' },
          { label: '250 * 18%', q: '250 * 18%' }
        ];

        searchDropdown.innerHTML = `
          <div class="p-3.5 space-y-3">
            ${appState.recentSearches.length > 0 ? `
              <div>
                <div class="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  <span>Recent Searches</span>
                  <button type="button" id="clearRecentSearchesBtn" class="text-[11px] text-rose-500 hover:underline font-semibold">Clear</button>
                </div>
                <div class="flex flex-wrap gap-1.5">
                  ${appState.recentSearches.map(r => `
                    <button type="button" data-search-chip="${r}" class="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition">
                      ${r}
                    </button>
                  `).join('')}
                </div>
              </div>
            ` : ''}
            <div>
              <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Trending Topics &amp; Instant Math Examples</div>
              <div class="flex flex-wrap gap-1.5">
                ${trendingTags.map(t => `
                  <button type="button" data-search-chip="${t.q}" class="px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-50/80 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/70 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60 transition">
                    ${t.label}
                  </button>
                `).join('')}
              </div>
            </div>
            <div class="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
              <span>Tip: Type any math expression (e.g. <code>18% of 450</code> or <code>sqrt(144)</code>) for an instant answer</span>
              <span class="font-mono">↑↓ Navigate • ↵ Open</span>
            </div>
          </div>
        `;
        searchDropdown.classList.remove('hidden');
        return;
      }

      // Case 2: Non-empty query -> Check Omnibox Instant Math + Ranked Calculator Matches
      const mathVal = tryEvaluateOmniboxMath(q);
      const matches = getFilteredCalculators(q, 'all');
      appState.currentSearchMatches = matches;
      if (appState.searchActiveIndex >= matches.length) {
        appState.searchActiveIndex = matches.length > 0 ? 0 : -1;
      }

      const mathCardHtml = mathVal !== null ? `
        <div class="p-3.5 bg-gradient-to-r from-indigo-600/10 via-cyan-500/10 to-transparent border-b border-indigo-200/60 dark:border-indigo-900/60 flex items-center justify-between gap-3">
          <div>
            <div class="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">Instant Omnibox Math Result</div>
            <div class="text-base font-extrabold font-mono-num text-slate-900 dark:text-white mt-0.5">${q} = <span class="text-indigo-600 dark:text-cyan-400">${fmtNum(mathVal, 8)}</span></div>
          </div>
          <div class="flex items-center gap-1.5 shrink-0">
            <button type="button" data-copy-omni="${mathVal}" class="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-500 transition">Copy</button>
            <button type="button" data-send-sci="${mathVal}" class="px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition">To Keypad</button>
          </div>
        </div>
      ` : '';

      if (matches.length === 0) {
        searchDropdown.innerHTML = `
          ${mathCardHtml}
          <div class="p-4 text-center space-y-2">
            <div class="text-xs text-slate-500">No calculator matched "<strong>${q}</strong>"</div>
            <div class="flex flex-wrap justify-center gap-1.5">
              <button type="button" data-search-chip="mortgage" class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[11px]">Mortgage</button>
              <button type="button" data-search-chip="bmi" class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[11px]">BMI</button>
              <button type="button" data-search-chip="percentage" class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[11px]">Percentage</button>
              <button type="button" data-search-chip="unit" class="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[11px]">Unit Converter</button>
            </div>
          </div>
        `;
      } else {
        const listHtml = matches.map((m, idx) => {
          const isSelected = idx === appState.searchActiveIndex;
          const tagsList = (SEARCH_KEYWORDS[m.id] || []).slice(0, 4).join(', ');
          return `
            <button type="button" data-open-calc="${m.id}" data-search-idx="${idx}" class="w-full px-4 py-2.5 text-left ${isSelected ? 'bg-indigo-50 dark:bg-slate-800/90 ring-1 ring-inset ring-indigo-500/40' : 'hover:bg-indigo-50/60 dark:hover:bg-slate-800/60'} flex items-center justify-between gap-3 transition">
              <div class="flex items-start gap-2.5 min-w-0">
                <span class="text-lg mt-0.5">${m.icon}</span>
                <div class="min-w-0">
                  <div class="text-xs font-bold text-slate-900 dark:text-white">${highlightText(m.name, q)}</div>
                  <div class="text-[11px] text-slate-500 dark:text-slate-400 truncate">${highlightText(m.desc, q)}</div>
                  <div class="text-[10px] text-indigo-600/80 dark:text-indigo-400/80 truncate mt-0.5">Keywords: ${highlightText(tagsList, q)}</div>
                </div>
              </div>
              <div class="flex flex-col items-end gap-1 shrink-0">
                <span class="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">${m.category}</span>
                ${isSelected ? '<span class="text-[10px] font-mono text-indigo-600 dark:text-indigo-400">↵ Enter</span>' : ''}
              </div>
            </button>
          `;
        }).join('');

        searchDropdown.innerHTML = `
          ${mathCardHtml}
          <div class="px-3.5 py-1.5 bg-slate-50 dark:bg-slate-950/60 text-[11px] font-semibold text-slate-500 flex items-center justify-between">
            <span>Found ${matches.length} matching calculator${matches.length > 1 ? 's' : ''}</span>
            <span class="font-mono text-[10px]">↑↓ to select • Enter to launch</span>
          </div>
          <div class="divide-y divide-slate-100 dark:divide-slate-800">${listHtml}</div>
        `;
      }
      searchDropdown.classList.remove('hidden');
    }

    searchInput.addEventListener('focus', () => {
      renderSearchDropdown();
    });

    searchInput.addEventListener('input', () => {
      appState.searchActiveIndex = 0;
      renderSearchDropdown();
    });

    searchInput.addEventListener('keydown', e => {
      const matches = appState.currentSearchMatches || [];
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (matches.length > 0) {
          appState.searchActiveIndex = (appState.searchActiveIndex + 1) % matches.length;
          renderSearchDropdown();
        }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (matches.length > 0) {
          appState.searchActiveIndex = (appState.searchActiveIndex - 1 + matches.length) % matches.length;
          renderSearchDropdown();
        }
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const q = searchInput.value.trim();
        if (appState.searchActiveIndex >= 0 && matches[appState.searchActiveIndex]) {
          const chosen = matches[appState.searchActiveIndex];
          saveRecentSearchTerm(q || chosen.name);
          selectCalculator(chosen.id, true);
          searchDropdown.classList.add('hidden');
        } else if (matches.length > 0) {
          saveRecentSearchTerm(q);
          selectCalculator(matches[0].id, true);
          searchDropdown.classList.add('hidden');
        } else {
          const mathVal = tryEvaluateOmniboxMath(q);
          if (mathVal !== null) {
            sciScreenInput.value = String(Number(mathVal.toPrecision(12)));
            pushSciTape(q, mathVal);
            searchDropdown.classList.add('hidden');
            showToast(`Sent ${q} = ${mathVal} to Scientific Calculator`);
          }
        }
      } else if (e.key === 'Escape') {
        searchDropdown.classList.add('hidden');
        searchInput.blur();
      }
    });

    function clearGlobalSearch(keepFocus = false) {
      searchInput.value = '';
      appState.searchQuery = '';
      appState.searchActiveIndex = -1;
      clearSearchInputBtn.classList.add('hidden');
      renderDirectory();
      if (keepFocus) {
        searchInput.focus();
        renderSearchDropdown();
      } else {
        searchDropdown.classList.add('hidden');
      }
    }

    clearSearchInputBtn.addEventListener('click', () => clearGlobalSearch(true));
    if (resetDirectorySearchBtn) {
      resetDirectorySearchBtn.addEventListener('click', () => clearGlobalSearch(false));
    }

    searchDropdown.addEventListener('click', e => {
      const chip = e.target.closest('[data-search-chip]');
      if (chip) {
        const val = chip.getAttribute('data-search-chip');
        searchInput.value = val;
        appState.searchActiveIndex = 0;
        saveRecentSearchTerm(val);
        renderSearchDropdown();
        searchInput.focus();
        return;
      }

      const clearRec = e.target.closest('#clearRecentSearchesBtn');
      if (clearRec) {
        appState.recentSearches = [];
        safeSetStorage('calcverse_recent_searches', []);
        renderSearchDropdown();
        return;
      }

      const copyOmni = e.target.closest('[data-copy-omni]');
      if (copyOmni) {
        const v = copyOmni.getAttribute('data-copy-omni');
        copyTextToClipboard(v, `Copied ${v} to clipboard!`);
        return;
      }

      const sendSci = e.target.closest('[data-send-sci]');
      if (sendSci) {
        const v = Number(sendSci.getAttribute('data-send-sci'));
        sciScreenInput.value = String(v);
        pushSciTape(searchInput.value.trim(), v);
        searchDropdown.classList.add('hidden');
        document.getElementById('heroScientificSection').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        showToast(`Sent ${v} to Scientific Calculator!`);
        return;
      }

      const openBtn = e.target.closest('[data-open-calc]');
      if (openBtn && searchInput.value.trim()) {
        saveRecentSearchTerm(searchInput.value.trim());
      }
    });

    // Close dropdown when clicking outside searchBoxContainer
    document.addEventListener('click', e => {
      const box = document.getElementById('searchBoxContainer');
      if (box && !box.contains(e.target)) {
        searchDropdown.classList.add('hidden');
      }
    });

    document.addEventListener('keydown', e => {
      if (e.key === '/' && document.activeElement !== searchInput && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
        e.preventDefault();
        searchInput.focus();
        renderSearchDropdown();
      } else if (e.key === 'Escape') {
        searchDropdown.classList.add('hidden');
      }
    });

    // =========================================================================
    // SIMPLE ACCOUNT OPENING (SIGN UP), LOGIN & PROFILE MANAGEMENT
    // =========================================================================
    const authModal = document.getElementById('authModal');
    const openAuthModalBtn = document.getElementById('openAuthModalBtn');
    const closeAuthModalBtn = document.getElementById('closeAuthModalBtn');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const authGuestContainer = document.getElementById('authGuestContainer');
    const authProfileContainer = document.getElementById('authProfileContainer');
    const authStatusBanner = document.getElementById('authStatusBanner');

    appState.users = safeGetStorage('calcverse_users', []);
    appState.currentUser = safeGetStorage('calcverse_current_user', null);

    // Google Identity Services (GSI) Configuration
    const DEFAULT_GOOGLE_AUTH_CONFIG = {
      clientId: 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com'
    };
    const googleAuthConfig = safeGetStorage('calcverse_google_auth_config', DEFAULT_GOOGLE_AUTH_CONFIG);

    function parseGoogleJwt(token) {
      try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
        return JSON.parse(jsonPayload);
      } catch (e) {
        return null;
      }
    }

    function handleGoogleCredentialResponse(response) {
      const payload = parseGoogleJwt(response && response.credential);
      if (!payload || !payload.email) {
        showAuthBanner('Google Sign-In failed to verify account details.');
        return;
      }
      const googleUser = {
        name: payload.name || payload.email.split('@')[0],
        email: payload.email.toLowerCase(),
        role: 'Google Account',
        provider: 'google',
        memberId: 'CV-GGL-' + Math.floor(1000 + (payload.email.length * 193) % 8999),
        favorites: [...appState.favorites]
      };
      const idx = appState.users.findIndex(u => u.email.toLowerCase() === googleUser.email);
      if (idx === -1) appState.users.push(googleUser);
      else appState.users[idx] = { ...appState.users[idx], ...googleUser };

      appState.currentUser = googleUser;
      safeSetStorage('calcverse_users', appState.users);
      safeSetStorage('calcverse_current_user', googleUser);
      syncWithWorkerApi('/api/auth/google', googleUser);
      updateAuthUI();
      showToast(`Signed in with Google as ${googleUser.name}!`);
    }

    function initGoogleSignInButton() {
      const cid = String(googleAuthConfig.clientId || '').trim();
      const isRealClientId = cid && !cid.startsWith('YOUR_GOOGLE_CLIENT_ID') && cid.includes('.apps.googleusercontent.com');
      const container = document.getElementById('googleSignInButtonContainer');
      const fallbackBtn = document.getElementById('fallbackGoogleSignInBtn');
      const hintEl = document.getElementById('googleAuthConfigHint');

      if (isRealClientId && window.google && window.google.accounts && window.google.accounts.id) {
        try {
          window.google.accounts.id.initialize({
            client_id: cid,
            callback: handleGoogleCredentialResponse
          });
          container.innerHTML = '';
          window.google.accounts.id.renderButton(container, {
            theme: document.documentElement.classList.contains('dark') ? 'filled_black' : 'outline',
            size: 'large',
            width: 260
          });
          fallbackBtn.classList.add('hidden');
          hintEl.classList.add('hidden');
          return;
        } catch (err) {
          // Fallback to button
        }
      }
      container.innerHTML = '';
      fallbackBtn.classList.remove('hidden');
    }

    document.getElementById('fallbackGoogleSignInBtn').addEventListener('click', () => {
      const cid = String(googleAuthConfig.clientId || '').trim();
      const isRealClientId = cid && !cid.startsWith('YOUR_GOOGLE_CLIENT_ID') && cid.includes('.apps.googleusercontent.com');
      if (!isRealClientId) {
        document.getElementById('googleAuthConfigHint').classList.remove('hidden');
        showAuthBanner('Google Client ID is not configured yet. Add your Client ID in ?admin=ads or DEFAULT_GOOGLE_AUTH_CONFIG.');
        return;
      }
      initGoogleSignInButton();
      if (window.google && window.google.accounts && window.google.accounts.id) {
        window.google.accounts.id.prompt();
      }
    });

    function showAuthBanner(msg, isError = true) {
      authStatusBanner.textContent = msg;
      authStatusBanner.className = isError
        ? 'px-3 py-2 rounded-xl text-xs font-semibold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
        : 'px-3 py-2 rounded-xl text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800';
      authStatusBanner.classList.remove('hidden');
    }

    function switchAuthTab() { authStatusBanner.classList.add('hidden'); }

    function updateAuthUI() {
      const headerLabel = document.getElementById('authHeaderLabel');
      const headerIcon = document.getElementById('authHeaderIcon');
      if (appState.currentUser) {
        const firstName = String(appState.currentUser.name || 'Account').split(' ')[0];
        headerIcon.innerHTML = '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        headerLabel.textContent = firstName;
        authGuestContainer.classList.add('hidden');
        authProfileContainer.classList.remove('hidden');

        document.getElementById('profileAvatarCircle').textContent = firstName.charAt(0).toUpperCase();
        document.getElementById('profileDisplayName').textContent = appState.currentUser.name;
        document.getElementById('profileDisplayEmail').textContent = appState.currentUser.email;
        document.getElementById('profileRoleBadge').textContent = appState.currentUser.role || 'Personal';
        document.getElementById('profileMemberId').textContent = `ID: ${appState.currentUser.memberId || 'CV-MEM-1001'}`;
        document.getElementById('profileStatFavs').textContent = String(appState.favorites.length);
        document.getElementById('profileStatPins').textContent = String(appState.pins.length);
        document.getElementById('profileStatHist').textContent = String(appState.history.length);
      } else {
        headerIcon.innerHTML = '<svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        headerLabel.textContent = 'Account';
        authProfileContainer.classList.add('hidden');
        authGuestContainer.classList.remove('hidden');
      }
    }


    async function syncWithWorkerApi(endpoint, payload) {
      if (location.protocol === 'https:' && location.hostname.endsWith('.workers.dev')) {
        try {
          const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          if (res.ok) return await res.json();
        } catch (err) {
          // Fallback to local storage cleanly
        }
      }
      return null;
    }

    openAuthModalBtn.addEventListener('click', () => {
      authStatusBanner.classList.add('hidden');
      updateAuthUI();
      initGoogleSignInButton();
      authModal.classList.remove('hidden');
    });

    document.getElementById('toggleLoginPwdBtn').addEventListener('click', e => {
      const inp = document.getElementById('loginPasswordInput');
      const isPwd = inp.type === 'password';
      inp.type = isPwd ? 'text' : 'password';
      e.currentTarget.textContent = isPwd ? 'Hide' : 'Show';
    });

    document.getElementById('toggleSignupPwdBtn').addEventListener('click', e => {
      const inp = document.getElementById('signupPasswordInput');
      const isPwd = inp.type === 'password';
      inp.type = isPwd ? 'text' : 'password';
      e.currentTarget.textContent = isPwd ? 'Hide' : 'Show';
    });

    document.getElementById('syncCloudAccountBtn').addEventListener('click', async () => {
      if (!appState.currentUser) return;
      await syncWithWorkerApi('/api/auth/sync', {
        email: appState.currentUser.email,
        favorites: appState.favorites,
        pins: appState.pins,
        history: appState.history
      });
      showToast('Account data synced! ');
    });

    closeAuthModalBtn.addEventListener('click', () => {
      authModal.classList.add('hidden');
    });


    // Handle Account Opening (Sign Up)
    signupForm.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('signupNameInput').value.trim();
      const email = document.getElementById('signupEmailInput').value.trim().toLowerCase();
      const password = document.getElementById('signupPasswordInput').value;
      const role = document.getElementById('signupRoleSelect').value;

      if (!name || !email || !password) {
        showAuthBanner('Please fill in all required fields.');
        return;
      }
      const existing = appState.users.find(u => u.email.toLowerCase() === email);
      if (existing) {
        showAuthBanner('An account with this email already exists. Please login instead.');
        return;
      }

      const phone = (document.getElementById('signupPhoneInput') || {}).value || '';
      const newUser = {
        name,
        email,
        phone: phone.trim(),
        password,
        role,
        memberId: 'CV-MEM-' + Math.floor(1000 + (email.length * 173) % 8999),
        favorites: [...appState.favorites]
      };
      syncWithWorkerApi('/api/auth/signup', newUser);
      appState.users.push(newUser);
      appState.currentUser = newUser;
      safeSetStorage('calcverse_users', appState.users);
      safeSetStorage('calcverse_current_user', newUser);
      signupForm.reset();
      updateAuthUI();
      showToast(`Welcome to CalcVerse, ${name}! Account opened `);
    });

    // Handle Login
    loginForm.addEventListener('submit', e => {
      e.preventDefault();
      const emailOrUser = document.getElementById('loginEmailInput').value.trim().toLowerCase();
      const password = document.getElementById('loginPasswordInput').value;

      const matched = appState.users.find(u =>
        (u.email.toLowerCase() === emailOrUser || u.name.toLowerCase() === emailOrUser) &&
        u.password === password
      );

      if (!matched) {
        showAuthBanner('Invalid email/username or password. Please check your credentials or open a new account.');
        return;
      }

      appState.currentUser = matched;
      safeSetStorage('calcverse_current_user', matched);
      loginForm.reset();
      updateAuthUI();
      showToast(`Signed in as ${matched.name}! `);
    });

    // Sign Out
    document.getElementById('logoutAccountBtn').addEventListener('click', () => {
      appState.currentUser = null;
      safeSetStorage('calcverse_current_user', null);
      authStatusBanner.classList.add('hidden');
      updateAuthUI();
      showToast('Signed out of your CalcVerse account');
    });

    // Export Account Backup (.JSON)
    document.getElementById('exportAccountDataBtn').addEventListener('click', () => {
      const payload = {
        account: appState.currentUser,
        savedCalculators: appState.favorites,
        pinnedScenarios: appState.pins,
        calculationHistory: appState.history,
        exportedAt: '2026-11-18'
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `calcverse_account_backup.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('Downloaded account backup (.JSON)!');
    });

    // Theme Toggle
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const themeIcon = document.getElementById('themeIcon');
    themeToggleBtn.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark');
      themeIcon.innerHTML = isDark ? '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>' : '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
      safeSetStorage('calcverse_dark', isDark);
    });

    // =========================================================================
    // CENTRALIZED GOOGLE ADSENSE CONFIGURATION & COMPLIANCE SYSTEM
    // =========================================================================
    /*
     * HOW TO CONFIGURE FOR PRODUCTION:
     * 1. Replace publisherId "ca-pub-XXXXXXXXXXXXXXXX" with your real AdSense Publisher ID.
     * 2. Replace each slotId ("SLOT_HEADER_BANNER", etc.) with your real 10-digit AdSense Ad Unit Slot ID.
     * 3. Keep reserveSpaceWhenUnavailable = false in production if you want unconfigured slots hidden,
     *    or toggle Layout Inspector in the UI to preview reserved CLS-safe containers.
     */
    const DEFAULT_ADSENSE_CONFIG = {
      publisherId: 'ca-pub-XXXXXXXXXXXXXXXX',
      autoAdsEnabled: true,
      lazyLoadAds: true,
      inspectorMode: false, // Set true via UI to inspect reserved ad containers before live approval
      placements: {
        header_banner: {
          id: 'header_banner',
          title: '1. Header Banner Advertisement',
          slotId: 'SLOT_HEADER_BANNER',
          enabled: true,
          desktop: true,
          mobile: true,
          format: 'horizontal',
          minHeightPx: 90
        },
        homepage_content: {
          id: 'homepage_content',
          title: '2. Homepage Content Advertisement',
          slotId: 'SLOT_HOMEPAGE_CONTENT',
          enabled: true,
          desktop: true,
          mobile: true,
          format: 'auto',
          minHeightPx: 100
        },
        between_sections: {
          id: 'between_sections',
          title: '3. Between Calculator Sections Ad',
          slotId: 'SLOT_BETWEEN_SECTIONS',
          enabled: true,
          desktop: true,
          mobile: true,
          format: 'auto',
          minHeightPx: 100
        },
        calculator_result: {
          id: 'calculator_result',
          title: '4. Calculator Result Page Ad (Below Formula)',
          slotId: 'SLOT_CALCULATOR_RESULT',
          enabled: true,
          desktop: true,
          mobile: true,
          format: 'rectangle',
          minHeightPx: 120
        },
        desktop_sidebar: {
          id: 'desktop_sidebar',
          title: '5. Desktop Sidebar Advertisement',
          slotId: 'SLOT_DESKTOP_SIDEBAR',
          enabled: true,
          desktop: true,
          mobile: false,
          format: 'vertical',
          minHeightPx: 250
        },
        footer_banner: {
          id: 'footer_banner',
          title: '6. Footer Banner Advertisement',
          slotId: 'SLOT_FOOTER_BANNER',
          enabled: true,
          desktop: true,
          mobile: true,
          format: 'horizontal',
          minHeightPx: 90
        },
        mobile_banner: {
          id: 'mobile_banner',
          title: '7. Mobile-Responsive Banner Ad',
          slotId: 'SLOT_MOBILE_BANNER',
          enabled: true,
          desktop: false,
          mobile: true,
          format: 'auto',
          minHeightPx: 80
        }
      }
    };

    const adConfig = safeGetStorage('calcverse_adsense_config', DEFAULT_ADSENSE_CONFIG);
    let adLazyObserver = null;

    function isRealPublisherIdConfigured() {
      const pid = String(adConfig.publisherId || '').trim();
      return /^ca-pub-\d{10,20}$/.test(pid);
    }

    function isRealSlotIdConfigured(slotId) {
      return /^\d{8,14}$/.test(String(slotId || '').trim());
    }

    function ensureAdSenseScriptLoaded() {
      if (window.__calcverseAdSenseInitialized) return;
      const existingScript = document.querySelector('script[src*="pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"]');
      if (existingScript) {
        window.__calcverseAdSenseInitialized = true;
        if (isRealPublisherIdConfigured()) {
          existingScript.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(adConfig.publisherId)}`;
        }
        return;
      }
      if (!isRealPublisherIdConfigured()) return;
      const s = document.createElement('script');
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(adConfig.publisherId)}`;
      document.head.appendChild(s);
      window.__calcverseAdSenseInitialized = true;
    }

    function pushAdUnitSafely(insEl) {
      if (!insEl || insEl.getAttribute('data-ad-pushed') === 'true') return;
      insEl.setAttribute('data-ad-pushed', 'true');
      if (!isRealPublisherIdConfigured()) return;
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (err) {
        // Gracefully handle ad blockers or unfilled slots without throwing console errors
      }
    }

    function renderAllAdPlacements() {
      ensureAdSenseScriptLoaded();
      const isMobileViewport = window.innerWidth < 768;

      if (adLazyObserver) {
        adLazyObserver.disconnect();
        adLazyObserver = null;
      }

      if (adConfig.lazyLoadAds && 'IntersectionObserver' in window) {
        adLazyObserver = new IntersectionObserver(entries => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              const ins = entry.target.querySelector('ins.adsbygoogle');
              if (ins) pushAdUnitSafely(ins);
              adLazyObserver.unobserve(entry.target);
            }
          });
        }, { rootMargin: '250px 0px' });
      }

      Object.values(adConfig.placements).forEach(p => {
        const container = document.getElementById(`ad-container-${p.id}`);
        if (!container) return;

        const deviceAllowed = isMobileViewport ? p.mobile : p.desktop;
        const realReady = isRealPublisherIdConfigured() && isRealSlotIdConfigured(p.slotId);

        // Hide container cleanly if disabled, wrong device, or placeholder IDs (unless Layout Inspector is active)
        if (!p.enabled || !deviceAllowed || (!realReady && !adConfig.inspectorMode)) {
          container.classList.add('hidden');
          container.innerHTML = '';
          return;
        }

        container.classList.remove('hidden');

        if (realReady) {
          container.innerHTML = `
            <div class="cv-ad-label">Advertisement</div>
            <div style="min-height:${p.minHeightPx}px" class="w-full rounded-xl bg-slate-100/60 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800/60 flex items-center justify-center overflow-hidden">
              <ins class="adsbygoogle"
                   style="display:block;width:100%;min-height:${p.minHeightPx}px"
                   data-ad-client="${adConfig.publisherId}"
                   data-ad-slot="${p.slotId}"
                   data-ad-format="${p.format || 'auto'}"
                   data-full-width-responsive="true"></ins>
            </div>
          `;
          const insEl = container.querySelector('ins.adsbygoogle');
          if (adLazyObserver && p.id !== 'header_banner') {
            adLazyObserver.observe(container);
          } else {
            pushAdUnitSafely(insEl);
          }
        } else {
          // Reserved container in Layout Inspector mode (never shows fake ads, only technical slot spec)
          container.innerHTML = `
            <div class="cv-ad-label">Advertisement • Reserved Container</div>
            <div style="min-height:${p.minHeightPx}px" class="w-full rounded-xl border border-dashed border-indigo-400/60 dark:border-indigo-700/60 bg-indigo-50/30 dark:bg-slate-900/60 p-3 flex flex-col items-center justify-center text-center">
              <div class="text-xs font-bold text-indigo-700 dark:text-indigo-300">${p.title}</div>
              <div class="text-[11px] font-mono text-slate-500 dark:text-slate-400 mt-0.5">client="${adConfig.publisherId}" • slot="${p.slotId}" • min-height: ${p.minHeightPx}px (CLS-safe)</div>
            </div>
          `;
        }
      });
    }

    function renderAdManagerModal() {
      document.getElementById('googleCfgClientIdInput').value = googleAuthConfig.clientId || '';
      document.getElementById('donateCfgMobileInput').value = donationConfig.mobileWallet || '';
      document.getElementById('donateCfgBnbInput').value = donationConfig.bnbAddress || '';
      document.getElementById('adCfgPublisherIdInput').value = adConfig.publisherId;
      document.getElementById('adCfgInspectorToggle').checked = Boolean(adConfig.inspectorMode);
      document.getElementById('adCfgAutoAdsToggle').checked = Boolean(adConfig.autoAdsEnabled);
      document.getElementById('adCfgLazyLoadToggle').checked = Boolean(adConfig.lazyLoadAds);

      const listEl = document.getElementById('adPlacementsConfigList');
      listEl.innerHTML = Object.values(adConfig.placements).map(p => `
        <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div class="space-y-0.5">
            <label class="flex items-center gap-2 font-bold cursor-pointer">
              <input type="checkbox" data-ad-enable="${p.id}" ${p.enabled ? 'checked' : ''} class="rounded text-indigo-600" />
              <span>${p.title}</span>
            </label>
            <div class="flex items-center gap-3 text-[11px] text-slate-500 pl-6">
              <label class="flex items-center gap-1 cursor-pointer"><input type="checkbox" data-ad-desk="${p.id}" ${p.desktop ? 'checked' : ''} /> Desktop</label>
              <label class="flex items-center gap-1 cursor-pointer"><input type="checkbox" data-ad-mob="${p.id}" ${p.mobile ? 'checked' : ''} /> Mobile</label>
              <span>Min-H: ${p.minHeightPx}px</span>
            </div>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-[11px] text-slate-400">Slot ID:</span>
            <input type="text" data-ad-slot-input="${p.id}" value="${p.slotId}" class="px-2.5 py-1 rounded-lg font-mono text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 w-44" />
          </div>
        </div>
      `).join('');
    }

    if (new URLSearchParams(window.location.search).get('admin') === 'ads') {
      document.getElementById('openAdManagerBtn').classList.remove('hidden');
    }

    document.getElementById('openAdManagerBtn').addEventListener('click', () => {
      renderAdManagerModal();
      document.getElementById('adManagerModal').classList.remove('hidden');
    });
    document.getElementById('closeAdManagerBtn').addEventListener('click', () => {
      document.getElementById('adManagerModal').classList.add('hidden');
    });

    document.getElementById('saveAdConfigBtn').addEventListener('click', () => {
      adConfig.publisherId = document.getElementById('adCfgPublisherIdInput').value.trim() || 'ca-pub-XXXXXXXXXXXXXXXX';
      adConfig.inspectorMode = document.getElementById('adCfgInspectorToggle').checked;
      adConfig.autoAdsEnabled = document.getElementById('adCfgAutoAdsToggle').checked;
      adConfig.lazyLoadAds = document.getElementById('adCfgLazyLoadToggle').checked;

      Object.keys(adConfig.placements).forEach(key => {
        const en = document.querySelector(`[data-ad-enable="${key}"]`);
        const dk = document.querySelector(`[data-ad-desk="${key}"]`);
        const mb = document.querySelector(`[data-ad-mob="${key}"]`);
        const sl = document.querySelector(`[data-ad-slot-input="${key}"]`);
        if (en) adConfig.placements[key].enabled = en.checked;
        if (dk) adConfig.placements[key].desktop = dk.checked;
        if (mb) adConfig.placements[key].mobile = mb.checked;
        if (sl) adConfig.placements[key].slotId = sl.value.trim() || `SLOT_${key.toUpperCase()}`;
      });

      donationConfig.mobileWallet = document.getElementById('donateCfgMobileInput').value.trim() || DEFAULT_DONATION_CONFIG.mobileWallet;
      donationConfig.bnbAddress = document.getElementById('donateCfgBnbInput').value.trim() || DEFAULT_DONATION_CONFIG.bnbAddress;
      googleAuthConfig.clientId = document.getElementById('googleCfgClientIdInput').value.trim() || DEFAULT_GOOGLE_AUTH_CONFIG.clientId;
      safeSetStorage('calcverse_google_auth_config', googleAuthConfig);
      initGoogleSignInButton();
      safeSetStorage('calcverse_donation_config', donationConfig);
      safeSetStorage('calcverse_adsense_config', adConfig);
      renderAllAdPlacements();
      document.getElementById('adManagerModal').classList.add('hidden');
      showToast('Saved Google AdSense configuration & updated placements! ');
    });

    document.getElementById('downloadAdsTxtBtn').addEventListener('click', () => {
      const pubClean = String(adConfig.publisherId || 'ca-pub-XXXXXXXXXXXXXXXX').replace(/^ca-/, '');
      const content = `google.com, ${pubClean}, DIRECT, f08c47fec0942fa0
`;
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ads.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('Downloaded ads.txt template!');
    });

    // =========================================================================
    // LEGAL, PRIVACY, TERMS, DISCLAIMER, ABOUT & CONTACT PAGES
    // =========================================================================
    const LEGAL_PAGES_CONTENT = {
      about: `
        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">About CalcVerse Pro</h3>
        <p><strong>CalcVerse Pro</strong> is a comprehensive, free online calculation platform engineered to help students, homeowners, financial planners, health enthusiasts, and engineers solve everyday and technical problems accurately.</p>
        <p>Our suite includes an interactive Scientific &amp; Expression Calculator alongside 24 specialized calculators spanning Finance (Mortgage, Loan Amortization, Compound Interest, Retirement, Inflation, Salary, ROI), Fitness &amp; Health (BMI, TDEE &amp; Calorie Macros, U.S. Navy Body Fat, Running Pace, Ideal Weight), Mathematics (Interactive Function Grapher, Percentage, Fraction Reducer, Statistics, Quadratic Solver, Right Triangle), and Science &amp; Utilities (Unit Converter, Ohm's Law, Age &amp; Date, GPA, IPv4 CIDR Subnet, Cryptographic Entropy).</p>
        <p>Every formula is documented step-by-step so users can verify how each result is derived.</p>
      `,
      contact: `
        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Contact Us</h3>
        <p>Have a question, formula suggestion, or bug report? Reach out to the CalcVerse editorial and engineering team using the form below or via email at <strong>support@calcverse.example.com</strong>.</p>
        <form id="legalContactForm" class="space-y-3 pt-2">
          <div>
            <label class="block text-xs font-bold mb-1">Your Name</label>
            <input type="text" required placeholder="Your Name" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
          </div>
          <div>
            <label class="block text-xs font-bold mb-1">Your Email</label>
            <input type="email" required placeholder="you@example.com" class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
          </div>
          <div>
            <label class="block text-xs font-bold mb-1">Message or Calculator Feedback</label>
            <textarea rows="3" required placeholder="Describe your question or suggestion..." class="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"></textarea>
          </div>
          <button type="submit" class="px-4 py-2 rounded-xl font-bold bg-indigo-600 hover:bg-indigo-500 text-white">Send Message</button>
        </form>
      `,
      privacy: `
        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Privacy Policy &amp; Google AdSense Disclosure</h3>
        <p><strong>Last Updated:</strong> November 18, 2026</p>
        <p><strong>1. Local Browser Calculation &amp; Storage:</strong> All calculations on CalcVerse Pro run directly in your browser. Saved tools, pinned scenarios, and calculation history are stored locally in your browser's <code>localStorage</code> and can be cleared at any time.</p>
        <p><strong>2. Google AdSense &amp; DoubleClick DART Cookie Disclosure:</strong></p>
        <ul class="list-disc pl-5 space-y-1">
          <li>Third-party vendors, including Google, use cookies to serve ads based on a user's prior visits to this website or other websites.</li>
          <li>Google's use of advertising cookies enables it and its partners to serve ads to our users based on their visit to CalcVerse and/or other sites on the Internet.</li>
          <li>Users may opt out of personalized advertising by visiting <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer" class="text-indigo-600 underline">Google Ads Settings</a> or <a href="https://www.aboutads.info" target="_blank" rel="noopener noreferrer" class="text-indigo-600 underline">www.aboutads.info</a>.</li>
        </ul>
        <p><strong>3. GDPR &amp; CCPA Privacy Rights:</strong> Users in the EEA, UK, and California have the right to request non-personalized advertisements, inspect stored preferences, or withdraw cookie consent at any time using the <em>Cookie Consent</em> link in our footer.</p>
      `,
      terms: `
        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Terms and Conditions of Use</h3>
        <p>By accessing and using CalcVerse Pro, you agree to comply with these Terms and Conditions:</p>
        <ul class="list-disc pl-5 space-y-1">
          <li><strong>Permitted Use:</strong> All calculators and downloadable reports are provided free of charge for personal, educational, and internal professional reference.</li>
          <li><strong>Intellectual Property:</strong> The CalcVerse code, layout, and custom visual generators are protected by applicable copyright laws.</li>
          <li><strong>Prohibited Conduct:</strong> Users must not attempt to generate automated/invalid clicks on advertisements, scrape resources excessively, or interfere with site security.</li>
        </ul>
      `,
      disclaimer: `
        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Financial, Health &amp; Technical Disclaimer</h3>
        <p><strong>Informational Purposes Only:</strong> All calculators on CalcVerse Pro—including Mortgage, Loan, Retirement, Tax, BMI, Calorie/TDEE, Body Fat, and Electrical/Engineering calculators—are provided strictly for educational and illustrative estimation purposes.</p>
        <p><strong>Not Financial or Medical Advice:</strong> Results from financial calculators do not constitute certified financial, tax, or mortgage lending advice. Results from fitness and health calculators do not constitute medical diagnosis or treatment advice. Always consult a qualified financial advisor, physician, or licensed engineer before making binding decisions.</p>
      `
    };

    function openLegalPage(tabKey) {
      const key = LEGAL_PAGES_CONTENT[tabKey] ? tabKey : 'about';
      document.getElementById('legalModalBody').innerHTML = LEGAL_PAGES_CONTENT[key];
      document.querySelectorAll('[data-legal-tab]').forEach(btn => {
        const active = btn.getAttribute('data-legal-tab') === key;
        btn.className = active
          ? 'legal-tab-btn px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600 text-white'
          : 'legal-tab-btn px-2.5 py-1 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800';
      });
      document.getElementById('legalComplianceModal').classList.remove('hidden');

      const contactForm = document.getElementById('legalContactForm');
      if (contactForm) {
        contactForm.addEventListener('submit', e => {
          e.preventDefault();
          contactForm.reset();
          document.getElementById('legalComplianceModal').classList.add('hidden');
          showToast('Thank you! Your message has been recorded.');
        });
      }
    }

    document.body.addEventListener('click', e => {
      const legalBtn = e.target.closest('[data-legal-page]');
      if (legalBtn) {
        openLegalPage(legalBtn.getAttribute('data-legal-page'));
        return;
      }
      const tabBtn = e.target.closest('[data-legal-tab]');
      if (tabBtn) {
        openLegalPage(tabBtn.getAttribute('data-legal-tab'));
      }
    });

    document.getElementById('closeLegalModalBtn').addEventListener('click', () => {
      document.getElementById('legalComplianceModal').classList.add('hidden');
    });

    // Cookie Consent Banner Logic
    const cookieBanner = document.getElementById('cookieConsentBanner');
    function initCookieConsent() {
      const savedConsent = safeGetStorage('calcverse_cookie_consent', null);
      if (!savedConsent) {
        cookieBanner.classList.remove('hidden');
      }
    }

    document.getElementById('cookieAcceptAllBtn').addEventListener('click', () => {
      safeSetStorage('calcverse_cookie_consent', { mode: 'personalized', timestamp: '2026-11-18' });
      cookieBanner.classList.add('hidden');
      showToast('Cookie preferences saved (Personalized Ads enabled)');
    });

    document.getElementById('cookieEssentialOnlyBtn').addEventListener('click', () => {
      safeSetStorage('calcverse_cookie_consent', { mode: 'non_personalized', timestamp: '2026-11-18' });
      cookieBanner.classList.add('hidden');
      showToast('Cookie preferences saved (Non-Personalized Ads only)');
    });

    document.getElementById('openCookieSettingsBtn').addEventListener('click', () => {
      cookieBanner.classList.remove('hidden');
    });

    // =========================================================================
    // SUPPORT & DONATION MODAL (MOBILE WALLET & BNB CHAIN BEP-20 ONLY)
    // =========================================================================
    const DEFAULT_DONATION_CONFIG = {
      mobileWallet: '01319034491',
      bnbAddress: '0xb4b633e43a784426033870ffa87f048912a609b5'
    };
    const donationConfig = safeGetStorage('calcverse_donation_config', DEFAULT_DONATION_CONFIG);

    const donateState = { amount: 5, method: 'mobile' };
    const donateModal = document.getElementById('donateModal');
    const donateCustomAmtInput = document.getElementById('donateCustomAmtInput');
    const donateSelectedAmtText = document.getElementById('donateSelectedAmtText');
    const donateMethodInfoBox = document.getElementById('donateMethodInfoBox');
    const donateThankYouBanner = document.getElementById('donateThankYouBanner');

    function updateDonateUI() {
      donateSelectedAmtText.textContent = String(donateState.amount || 5);
      document.querySelectorAll('.donate-amt-btn').forEach(b => {
        const active = Number(b.getAttribute('data-donate-amt')) === Number(donateState.amount);
        b.className = active
          ? 'donate-amt-btn py-2 rounded-xl border-2 border-amber-500 bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 transition'
          : 'donate-amt-btn py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-amber-500 bg-white/70 dark:bg-slate-800/70 transition';
      });
      document.querySelectorAll('.donate-method-btn').forEach(b => {
        const active = b.getAttribute('data-donate-method') === donateState.method;
        b.className = active
          ? 'donate-method-btn py-2.5 px-3 rounded-xl bg-indigo-600 text-white shadow-sm transition'
          : 'donate-method-btn py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 transition';
      });

      if (donateState.method === 'mobile') {
        donateMethodInfoBox.innerHTML = `
          <div class="flex items-center justify-between gap-2">
            <span class="font-bold text-slate-800 dark:text-white"><span class="inline-flex items-center gap-1.5"><svg class="w-3.5 h-3.5 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg><span>Mobile Wallet</span></span> (bKash / Nagad / Rocket)</span>
            <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">Send Money</span>
          </div>
          <div class="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
            <code class="text-[11px] font-mono break-all text-slate-800 dark:text-slate-200">${donationConfig.mobileWallet}</code>
            <button type="button" id="copyMobileWalletBtn" class="shrink-0 px-2 py-1 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 text-[11px] font-bold hover:bg-indigo-100 transition">Copy</button>
          </div>
          <p class="text-[11px] text-slate-500 dark:text-slate-400">Send $${donateState.amount} equivalent, then add your Transaction ID in the note below if you'd like.</p>
        `;
        const copyMob = document.getElementById('copyMobileWalletBtn');
        if (copyMob) {
          copyMob.addEventListener('click', () => copyTextToClipboard(donationConfig.mobileWallet, 'Copied Mobile Wallet number!'));
        }
      } else {
        donateMethodInfoBox.innerHTML = `
          <div class="flex items-center justify-between gap-2">
            <span class="font-bold text-slate-800 dark:text-white">BNB Smart Chain Deposit</span>
            <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">Network: BEP-20</span>
          </div>
          <div class="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
            <code class="text-[11px] font-mono break-all text-slate-800 dark:text-slate-200">${donationConfig.bnbAddress}</code>
            <button type="button" id="copyBnbAddressBtn" class="shrink-0 px-2 py-1 rounded bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 text-[11px] font-bold hover:bg-amber-100 transition">Copy</button>
          </div>
          <p class="text-[11px] text-amber-700 dark:text-amber-300">Send only BNB / BEP-20 tokens on <strong>BNB Smart Chain (BSC)</strong>.</p>
        `;
        const copyBnb = document.getElementById('copyBnbAddressBtn');
        if (copyBnb) {
          copyBnb.addEventListener('click', () => copyTextToClipboard(donationConfig.bnbAddress, 'Copied BNB (BEP-20) deposit address!'));
        }
      }
    }

    document.getElementById('openDonateModalBtn').addEventListener('click', () => {
      donateThankYouBanner.classList.add('hidden');
      updateDonateUI();
      donateModal.classList.remove('hidden');
    });
    document.getElementById('closeDonateModalBtn').addEventListener('click', () => {
      donateModal.classList.add('hidden');
    });

    document.querySelectorAll('.donate-amt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        donateState.amount = Number(btn.getAttribute('data-donate-amt')) || 5;
        donateCustomAmtInput.value = String(donateState.amount);
        updateDonateUI();
      });
    });

    donateCustomAmtInput.addEventListener('input', () => {
      const val = parseFloat(donateCustomAmtInput.value);
      donateState.amount = isFinite(val) && val > 0 ? val : 1;
      updateDonateUI();
    });

    document.querySelectorAll('.donate-method-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        donateState.method = btn.getAttribute('data-donate-method');
        updateDonateUI();
      });
    });

    document.getElementById('submitDonateBtn').addEventListener('click', () => {
      const note = document.getElementById('donateNoteInput').value.trim();
      const methodLabel = donateState.method === 'mobile' ? 'Mobile Wallet' : 'BNB Chain (BEP-20)';
      donateThankYouBanner.textContent = `Thank you for your $${donateState.amount} ${methodLabel} support!${note ? ' Ref/Note: "' + note + '"' : ''} `;
      donateThankYouBanner.classList.remove('hidden');
      showToast(`Recorded $${donateState.amount} ${methodLabel} support! `);
    });

    // Global Classy Click Ripple Effect on All Interactive Clicks
    document.addEventListener('pointerdown', e => {
      const targetBtn = e.target.closest('button, [role="button"], a, .cat-pill');
      if (!targetBtn || targetBtn.disabled) return;
      const ripple = document.createElement('span');
      ripple.className = 'cv-click-ripple';
      ripple.style.left = `${e.clientX}px`;
      ripple.style.top = `${e.clientY}px`;
      document.body.appendChild(ripple);
      setTimeout(() => {
        if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
      }, 540);
    }, { passive: true });

    // Init App
    (function initApp() {
      const savedDark = safeGetStorage('calcverse_dark', false);
      if (savedDark) {
        document.documentElement.classList.add('dark');
        themeIcon.innerHTML = '<svg class="w-4 h-4 inline-block shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';
      }
      updateSciIndicators();
      renderPopularQuickGrid();
      renderFavorites();
      renderPins();
      renderHistory();
      renderDirectory();
      renderActiveWorkspace();
      updateAuthUI();
      renderAllAdPlacements();
      initCookieConsent();
    })();
